<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" class="dm-svg dm-flexbox dm-flexboxlegacy dm-no-flexboxtweener dm-flexwrap dm-supports dm-cssvwunit dm-passiveeventlisteners pointer skrollr skrollr-desktop" style="">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

        <!-- ========= Meta Tags ========= -->
        <!-- PWA settings -->
        <script async="" src="./Electronic Waves Home_files/sp-2.0.0-dm-0.1.min.js.download"></script>
        <script>
            function toHash(str) {
                var hash = 5381,
                    i = str.length;
                while (i) {
                    hash = hash * 33 ^ str.charCodeAt(--i)
                }
                return hash >>> 0
            }

            var cacheKey = '-1122745433~661b5333962b49ba8fdfe2ded2230e5e~home~~false~desktop:::PAGES_SHORT_CACHE:::1554825109000';
            var hashedCacheKey = cacheKey ? toHash(cacheKey) : '';
        </script>
        <script>
            ( function(global) {
                    const cacheKey = global.cacheKey;
                    const isOffline = ('onLine' in navigator) && (navigator.onLine === false);
                    const hasServiceWorkerSupport = 'serviceWorker' in navigator;
                    if (isOffline) {
                        console.log('offline mode');
                    }
                    if (!hasServiceWorkerSupport) {
                        console.log('service worker is not supported');
                    }
                    if (hasServiceWorkerSupport && !isOffline) {

                        window.addEventListener('load', function() {
                            const serviceWorkerPath = '/runtime-service-worker.js?v=1';
                            navigator.serviceWorker.register(serviceWorkerPath, {
                                scope : './'
                            }).then(function(registration) {
                                // Registration was successful
                                console.log('ServiceWorker registration successful with scope: ', registration.scope);
                                checkCacheKey().then(function(result) {
                                    if (result && result.newKey) {
                                        // stale version
                                        console.log('stale version, current key:', cacheKey, ';;; new key:', result.newKey);
                                        messageServiceWorker({
                                            command : 'deletePagesCache'
                                        });
                                    }
                                });
                            }, function(err) {
                                // registration failed :(
                                console.log('ServiceWorker registration failed: ', err);
                            }).catch(function(err) {
                                console.log(err)
                            });
                        });

                        // helper function to refresh the page
                        var refreshPage = ( function() {
                                var refreshing;
                                return function() {
                                    if (refreshing)
                                        return;
                                    // prevent multiple refreshes
                                    var refreshkey = 'refreshed' + location.href;
                                    var prevRefresh = localStorage.getItem(refreshkey);
                                    if (prevRefresh) {
                                        localStorage.removeItem(refreshkey);
                                        if ((Date.now() - prevRefresh) < 30000) {
                                            return;
                                            // dont go into a refresh loop
                                        }
                                    }
                                    refreshing = true;
                                    localStorage.setItem(refreshkey, Date.now());
                                    console.log('refereshing page');
                                    window.location.reload();
                                }
                            }())

                        // checks the updated cache key
                        function checkCacheKey() {
                            var baseUrl = '/_dm/s/rt/actions/cacheKey';
                            const uri = location.pathname;
                            var cacheKeyUrl = baseUrl + (baseUrl.indexOf('?') > -1 ? '&' : '?') + 'skip_sw_cache&uri=' + encodeURIComponent(uri);
                            return fetch(cacheKeyUrl).then(function(resp) {
                                return (resp && resp.json) ? resp.json() : {};
                            }).then(function(cacheObj) {
                                if (cacheObj && cacheObj.value) {
                                    if (cacheObj.value !== cacheKey) {
                                        // stale version
                                        return {
                                            newKey : cacheObj.value
                                        };
                                    }
                                }
                            }).catch(function(err) {
                                return {};
                            });
                        }

                        function messageServiceWorker(data) {
                            return new Promise(function(resolve, reject) {
                                if (navigator.serviceWorker.controller) {
                                    var worker = navigator.serviceWorker.controller;
                                    var messageChannel = new MessageChannel();
                                    messageChannel.port1.onmessage = replyHandler;
                                    worker.postMessage(data, [messageChannel.port2]);
                                    function replyHandler(event) {
                                        resolve(event.data);
                                    }

                                } else {
                                    resolve();
                                }
                            })
                        }

                    }
                }(window))
        </script>
        <!-- Add manifest -->
        <!-- End PWA settings -->

        <link rel="canonical" href="https://www.electronicwavesradio.com/">

        <meta id="view" name="viewport" content=", initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=0, viewport-fit=cover">

        <meta name="apple-mobile-web-app-capable" content="yes">

        <!--Add favorites icons-->

        <link rel="apple-touch-icon" href="https://cdn.website-editor.net/661b5333962b49ba8fdfe2ded2230e5e/dms3rep/multi/IMG_0096.PNG">

        <link rel="icon" type="image/x-icon" href="https://cdn.website-editor.net/661b5333962b49ba8fdfe2ded2230e5e/site_favicon_16_1550329868307.ico">

        <!-- End favorite icons -->

        <!-- render the required CSS and JS in the head section -->
        <script>
            if (!window.requestIdleCallback) {
                window.requestIdleCallback = function(fn) {
                    setTimeout(fn, 0);
                }
            }

            function loadCSS(link) {
                var urlParams = new URLSearchParams(window.location.search);
                var noCSS = !!urlParams.get('nocss');
                var cssTimeout = urlParams.get('cssTimeout') || 0;

                if (noCSS) {
                    return;
                }
                requestIdleCallback(function() {
                    window.setTimeout(function() {
                        link.onload = null;
                        link.rel = 'stylesheet';
                        link.type = 'text/css'
                    }, parseInt(cssTimeout, 10));
                });
            }

        </script>
        <script>
            (function(n) {
                "use strict";
                if (!n.l) {
                    n.l = function() {
                    }
                }
                var o = loadCSS.t = {};
                o.o = function() {
                    var l;
                    try {
                        l = n.document.createElement("link").relList.supports("preload")
                    } catch(e) {
                        l = false
                    }
                    return function() {
                        return l
                    }
                }();
                o.i = function(e) {
                    var l = e.media || "all";
                    function enableStylesheet() {
                        if (e.addEventListener) {
                            e.removeEventListener("load", enableStylesheet)
                        } else if (e.attachEvent) {
                            e.detachEvent("onload", enableStylesheet)
                        }
                        e.setAttribute("onload", null);
                        e.media = l
                    }

                    if (e.addEventListener) {
                        e.addEventListener("load", enableStylesheet)
                    } else if (e.attachEvent) {
                        e.attachEvent("onload", enableStylesheet)
                    }
                    setTimeout(function() {
                        e.rel = "stylesheet";
                        e.media = "only x"
                    });
                    setTimeout(enableStylesheet, 3e3)
                };
                o.s = function() {
                    if (o.o()) {
                        return
                    }
                    var e = n.document.getElementsByTagName("link");
                    for (var l = 0; l < e.length; l++) {
                        var t = e[l];
                        if (t.rel === "preload" && t.getAttribute("as") === "style" && !t.getAttribute("data-loadcss")) {
                            t.setAttribute("data-loadcss", true);
                            o.i(t)
                        }
                    }
                };
                if (!o.o()) {
                    o.s();
                    var e = n.setInterval(o.s, 500);
                    if (n.addEventListener) {
                        n.addEventListener("load", function() {
                            o.s();
                            n.clearInterval(e)
                        })
                    } else if (n.attachEvent) {
                        n.attachEvent("onload", function() {
                            o.s();
                            n.clearInterval(e)
                        })
                    }
                }
                if ( typeof exports !== "undefined") {
                    exports.l = loadCSS
                } else {
                    n.l = loadCSS
                }
            })( typeof global !== "undefined" ? global : this);
        </script>

        <!-- ========= CSS Section ========= -->
        <!-- Foundation CSS -->
        <link rel="stylesheet" type="text/css" href="./Electronic Waves Home_files/d-css-foundation.min.css">

        <!-- Google Fonts Include -->

        <link type="text/css" rel="stylesheet" href="./Electronic Waves Home_files/css">

        <link type="text/css" rel="stylesheet" href="./Electronic Waves Home_files/additional-fonts.css">

        <link rel="stylesheet" type="text/css" href="./Electronic Waves Home_files/css-font-package.min.css">

        <!-- RT CSS Include d-css-runtime-desktop-one-package-new-->
        <link rel="stylesheet" type="text/css" href="./Electronic Waves Home_files/d-css-runtime-desktop-one-package-new.min.css">

        <!-- End of RT CSS Include -->

        <style id="pageAdditionalWidgetsCss" type="text/css">
            /**//**//**//**/
            .dw{min-width:170px;padding:0 10px;position:absolute;top:5%;left:0;z-index:1001;color:#000;font-family:arial,verdana,sans-serif;font-size:12px;text-shadow:none}.dwi {position:static;margin:5px;display:inline-block}
                .dwwr{zoom:1}.dwo{width:100%;background:#000;position:absolute;top:0;left:0;z-index:1000;opacity:.7;filter:Alpha(Opacity=70)}.dwc{float:left;margin:0 2px 5px 2px;padding-top:30px}.dwcc{clear:both}.dwl{text-align:center;line-height:30px;height:30px;white-space:nowrap;position:absolute;top:-30px;width:100%}
                .dwv{padding:10px 0;border-bottom:1px solid #000}.dwrc{border-radius:3px}.dwwc{margin:0;padding:0 2px;position:relative;background:#000;zoom:1}.dwwl{margin:4px 2px;position:relative;background:#888;background:-o-linear-gradient(#000 0,#333 35%,#888 50%,#333 65%,#000 100%)}
                .dww{margin:0 2px;overflow:hidden;position:relative}.dwsc .dww{color:#fff;background:#444;background:-o-linear-gradient(#000 0,#444 45%,#444 55%,#000 100%)}.dww ul{list-style:none;margin:0;padding:0;position:relative;z-index:2}
                .dww li{list-style:none;margin:0;padding:0 5px;display:block;text-align:center;line-height:40px;font-size:26px;white-space:nowrap;text-shadow:0 1px 1px #000;opacity:.3;filter:Alpha(Opacity=30)}.dww li.dw-v{opacity:1;filter:Alpha(Opacity=100)}
                .dww li.dw-h{visibility:hidden}.dwwb{position:absolute;z-index:4;left:0;cursor:pointer;width:100%;height:40px;text-align:center;opacity:1;-webkit-transition:opacity .2s linear}.dwa .dwwb{opacity:0}.dwwbp{top:0;border-radius:3px 3px 0 0;font-size:40px}
                .dwwbm{bottom:0;border-radius:0 0 3px 3px;font-size:32px;font-weight:bold}.dwpm .dwwc{background:transparent}.dwpm .dww{margin:-1px}.dwpm .dww li{text-shadow:none}.dwpm .dwwol{display:none}.dwwo{position:absolute;z-index:3;top:0;left:0;width:100%;height:100%;background:-o-linear-gradient(#000 0,rgba(44,44,44,0) 52%,rgba(44,44,44,0) 48%,#000 100%)}
                .dwwol{position:absolute;z-index:1;top:50%;left:0;width:100%;height:0;margin-top:-1px;border-top:1px solid #333;border-bottom:1px solid #555}.dwbg .dwb{display:block;height:40px;line-height:40px;padding:0 15px;margin:0 2px;font-size:14px;font-weight:bold;text-decoration:none;text-shadow:0 -1px 1px #000;border-radius:5px;-moz-border-radius:5px;-webkit-border-radius:5px;box-shadow:0 1px 3px rgba(0,0,0,0.5);-moz-box-shadow:0 1px 3px rgba(0,0,0,0.5);-webkit-box-shadow:0 1px 3px rgba(0,0,0,0.5);color:#fff;background:#000;background:-o-linear-gradient(#6e6e6e 50%,#000 50%)}
                .dwbc{padding:5px 0;text-align:center;clear:both}.dwbw{display:inline-block;width:50%}.dwhl{padding-top:10px}.dwhl .dwl{display:none}.dwbg{background:#fff;border-radius:3px;-webkit-border-radius:3px;-moz-border-radius:3px}
                .dwbg .dwpm .dww{color:#000;background:#fff;border:1px solid #AAA}.dwbg .dwwb{background:#ccc;color:#888;text-shadow:0 -1px 1px #333;box-shadow:0 0 5px #333;-webkit-box-shadow:0 0 5px #333;-moz-box-shadow:0 0 5px #333}
                .dwbg .dwwbp{background:-o-linear-gradient(#f7f7f7,#bdbdbd)}.dwbg .dwwbm{background:-o-linear-gradient(#bdbdbd,#f7f7f7)}.dwbg .dwb-a{background:#3c7500;background:-o-linear-gradient(#94c840 50%,#3c7500 50%)}
                .dwbg .dwwl .dwb-a{background:#3c7500;background:-o-linear-gradient(#94c840,#3c7500)}/**//**//**//**/.dmMobileBody .dwwol{z-index:10000099991}.dmMobileBody .dww ul{z-index:10000099992}.dmMobileBody .dwwo{z-index:10000099993}
                .dmMobileBody .dwwb{z-index:10000099994}.dmMobileBody .dwo{z-index:10000099995}.dmMobileBody .dw{z-index:10000099996}.xdsoft_datetimepicker{box-shadow:0 5px 15px -5px rgba(0,0,0,0.506);background:#fff;border-bottom:1px solid #bbb;border-left:1px solid #ccc;border-right:1px solid #ccc;border-top:1px solid #ccc;color:#333;display:block;font-family:"Helvetica Neue","Helvetica","Arial",sans-serif;padding:8px;padding-left:0;padding-top:2px;position:absolute;z-index:9999;-moz-box-sizing:border-box;box-sizing:border-box;display:none}
                .xdsoft_datetimepicker iframe{position:absolute;left:0;top:0;width:75px;height:210px;background:transparent;border:0}/**/.xdsoft_datetimepicker button{border:none!important}.xdsoft_noselect{-webkit-touch-callout:none;-webkit-user-select:none;-khtml-user-select:none;-moz-user-select:none;-ms-user-select:none;-o-user-select:none;user-select:none}
                .xdsoft_noselect::selection{background:transparent}.xdsoft_noselect::-moz-selection{background:transparent}.xdsoft_datetimepicker.xdsoft_inline{display:inline-block;position:static;box-shadow:none}.xdsoft_datetimepicker *{-moz-box-sizing:border-box;box-sizing:border-box;padding:0;margin:0}
                .xdsoft_datetimepicker .xdsoft_datepicker,.xdsoft_datetimepicker .xdsoft_timepicker{display:none}.xdsoft_datetimepicker .xdsoft_datepicker.active,.xdsoft_datetimepicker .xdsoft_timepicker.active{display:block}
                .xdsoft_datetimepicker .xdsoft_datepicker{width:224px;float:left;margin-left:8px}.xdsoft_datetimepicker .xdsoft_timepicker{width:58px;float:left;text-align:center;margin-left:8px;margin-top:0}.xdsoft_datetimepicker .xdsoft_datepicker.active+.xdsoft_timepicker{margin-top:8px;margin-bottom:3px}
                .xdsoft_datetimepicker .xdsoft_mounthpicker{position:relative;text-align:center}.xdsoft_datetimepicker .xdsoft_prev,.xdsoft_datetimepicker .xdsoft_next,.xdsoft_datetimepicker .xdsoft_today_button{background-image:url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFoAAAAeCAYAAACsYQl4AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA2ZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDozQjRCQjRGREU4MkNFMzExQjRDQkIyRDJDOTdBRUI1MCIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpCQjg0OUYyNTZDODAxMUUzQjMwM0IwMERBNUU0ODQ5NSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpCQjg0OUYyNDZDODAxMUUzQjMwM0IwMERBNUU0ODQ5NSIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M2IChXaW5kb3dzKSI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkI5NzE3MjFBN0E2Q0UzMTFBQjJEQjgzMDk5RTNBNTdBIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjNCNEJCNEZERTgyQ0UzMTFCNENCQjJEMkM5N0FFQjUwIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+aQvATgAAAfVJREFUeNrsmr1OwzAQxzGtkPjYEAuvVGAvfQIGRKADE49gdLwDDwBiZ2RhQUKwICQkWLsgFiRQuIBTucFJ/XFp4+hO+quqnZ4uvzj2nV2RpukCW/22yAgYNINmc7du7DcghCjrkqgOKjF1znpt6rZ0AGWQj7TvCU8d9UM+QAGDrhdyc2Bnc1WVVPBev9V8lBnY+rDwncWZThG4xk4lmxtJy2AHgoY/FySgbSBPwPZ8mEXbQx3aDERb0EbYAYFC7pcAtAvkMWwC0D3NX58S9D/YnoGC7nPWr3Dg9JTbtuHhDShBT8D2CBSK/iIEvVXxpuxSgh7DdgwUTL4iA92zmJb6lKB/YTsECmV+IgK947AGDIqgQ/LojsO135Hn51l2cWlov0JdGNrPUceueXRwilSVgkUyom9Rd6gbLfYTDeO+1v6orn0InTogYDGUkYLO3/wc9BdqqTCKP1Tfi+oTIaCBIL2TES+GTyruT9S61p6BHam+99DFEAgLFklYsIBHwSI9QY80H5ta+1rB/6ovaKihBJeEJbgLbBlQgl+j3lDPqA2tfQV1j3pVn8s+oKHGTSVJ+FqDLeR5bCqJ2E/BCycsoLZETXaKGs7rhKVt+9HZScrZNMi88V8P7LlDbvOZYaJVpMMmBCT4n0o8dTBoNgbdWPsRYACs3r7XyNfbnAAAAABJRU5ErkJggg==')}
                .xdsoft_datetimepicker .xdsoft_prev{float:left;background-position:-20px 0}.xdsoft_datetimepicker .xdsoft_today_button{float:left;background-position:-70px 0;margin-left:5px}.xdsoft_datetimepicker .xdsoft_next{float:right;background-position:0 0px}
                .xdsoft_datetimepicker .xdsoft_next,.xdsoft_datetimepicker .xdsoft_prev,.xdsoft_datetimepicker .xdsoft_today_button{background-color:transparent;background-repeat:no-repeat;border:0 none currentColor;cursor:pointer;display:block;height:30px;opacity:.5;outline:medium none currentColor;overflow:hidden;padding:0;position:relative;text-indent:100%;white-space:nowrap;width:20px}
                .xdsoft_datetimepicker .xdsoft_timepicker .xdsoft_prev,.xdsoft_datetimepicker .xdsoft_timepicker .xdsoft_next{float:none;background-position:-40px -15px;height:15px;width:30px;display:block;margin-left:14px;margin-top:7px}
                .xdsoft_datetimepicker .xdsoft_timepicker .xdsoft_prev{background-position:-40px 0;margin-bottom:7px;margin-top:0}.xdsoft_datetimepicker .xdsoft_timepicker .xdsoft_time_box{height:151px;overflow:hidden;border-bottom:1px solid #ddd}
                .xdsoft_datetimepicker .xdsoft_timepicker .xdsoft_time_box>div>div{background:#f5f5f5;border-top:1px solid #ddd;color:#666;font-size:12px;text-align:center;border-collapse:collapse;cursor:pointer;border-bottom-width:0;height:25px;line-height:25px}
                .xdsoft_datetimepicker .xdsoft_timepicker .xdsoft_time_box>div>div:first-child{border-top-width:0}.xdsoft_datetimepicker .xdsoft_today_button:hover,.xdsoft_datetimepicker .xdsoft_next:hover,.xdsoft_datetimepicker .xdsoft_prev:hover{opacity:1}
                .xdsoft_datetimepicker .xdsoft_label{display:inline;position:relative;z-index:9999;margin:0;padding:5px 3px;font-size:14px;line-height:20px;font-weight:bold;background-color:#fff;float:left;width:182px;text-align:center;cursor:pointer}
                .xdsoft_datetimepicker .xdsoft_label:hover{text-decoration:underline}.xdsoft_datetimepicker .xdsoft_label>.xdsoft_select{border:1px solid #ccc;position:absolute;display:block;right:0;top:30px;z-index:101;display:none;background:#fff;max-height:160px;overflow-y:hidden}
                .xdsoft_datetimepicker .xdsoft_label>.xdsoft_select.xdsoft_monthselect{right:-7px}.xdsoft_datetimepicker .xdsoft_label>.xdsoft_select.xdsoft_yearselect{right:2px}.xdsoft_datetimepicker .xdsoft_label>.xdsoft_select>div>.xdsoft_option:hover{color:#fff;background:#ff8000}
                .xdsoft_datetimepicker .xdsoft_label>.xdsoft_select>div>.xdsoft_option{padding:2px 10px 2px 5px}.xdsoft_datetimepicker .xdsoft_label>.xdsoft_select>div>.xdsoft_option.xdsoft_current{background:#3af;box-shadow:#178fe5 0 1px 3px 0 inset;color:#fff;font-weight:700}
                .xdsoft_datetimepicker .xdsoft_month{width:90px;text-align:right}.xdsoft_datetimepicker .xdsoft_calendar{clear:both}.xdsoft_datetimepicker .xdsoft_year{width:56px}.xdsoft_datetimepicker .xdsoft_calendar table{border-collapse:collapse;width:100%}
                .xdsoft_datetimepicker .xdsoft_calendar td>div{padding-right:5px}.xdsoft_datetimepicker .xdsoft_calendar th{height:25px}.xdsoft_datetimepicker .xdsoft_calendar td,.xdsoft_datetimepicker .xdsoft_calendar th{width:14.2857142%;text-align:center;background:#f5f5f5;border:1px solid #ddd;color:#666;font-size:12px;text-align:right;padding:0;border-collapse:collapse;cursor:pointer;height:25px}
                .xdsoft_datetimepicker .xdsoft_calendar th{background:#f1f1f1}.xdsoft_datetimepicker .xdsoft_calendar td.xdsoft_today{color:#3af}.xdsoft_datetimepicker .xdsoft_calendar td.xdsoft_default,.xdsoft_datetimepicker .xdsoft_calendar td.xdsoft_current,.xdsoft_datetimepicker .xdsoft_timepicker .xdsoft_time_box>div>div.xdsoft_current{background:#3af;box-shadow:#178fe5 0 1px 3px 0 inset;color:#fff;font-weight:700}
                .xdsoft_datetimepicker .xdsoft_calendar td.xdsoft_other_month,.xdsoft_datetimepicker .xdsoft_calendar td.xdsoft_disabled,.xdsoft_datetimepicker .xdsoft_time_box>div>div.xdsoft_disabled{opacity:.5}.xdsoft_datetimepicker .xdsoft_calendar td.xdsoft_other_month.xdsoft_disabled{opacity:.2}
                .xdsoft_datetimepicker .xdsoft_calendar td:hover,.xdsoft_datetimepicker .xdsoft_timepicker .xdsoft_time_box>div>div:hover{color:#fff!important;background:#ff8000!important;box-shadow:none!important}.xdsoft_datetimepicker .xdsoft_calendar td.xdsoft_disabled:hover,.xdsoft_datetimepicker .xdsoft_timepicker .xdsoft_time_box>div>div.xdsoft_disabled:hover{color:inherit!important;background:inherit!important;box-shadow:inherit!important}
                .xdsoft_datetimepicker .xdsoft_calendar th{font-weight:700;text-align:center;color:#999;cursor:default}.xdsoft_datetimepicker .xdsoft_copyright{color:#ccc!important;font-size:10px;clear:both;float:none;margin-left:8px}
                .xdsoft_datetimepicker .xdsoft_copyright a{color:#eee!important}.xdsoft_datetimepicker .xdsoft_copyright a:hover{color:#aaa!important}.xdsoft_time_box{position:relative;border:1px solid #ccc}.xdsoft_scrollbar>.xdsoft_scroller{background:#ccc!important;height:20px;border-radius:3px}
                .xdsoft_scrollbar{position:absolute;width:7px;width:7px;right:0;top:0;bottom:0;cursor:pointer}.xdsoft_scroller_box{position:relative}/**/.dmLargeBody #dm .dmRespRow .dmRespCol.large-12 .dmform[data-layout="layout-2"] .dmform-wrapper .dmformsubmit.dmWidget,.dmLargeBody #dm .dmRespRow .dmRespCol.large-11 .dmform[data-layout="layout-2"] .dmform-wrapper .dmformsubmit.dmWidget{width:-webkit-fit-content;width:-moz-fit-content;width:fit-content}
                #dm .dmformsubmit input[type="submit"]{text-align:inherit}#dm div.dmInner .dmform[data-layout="layout-2"] .dmforminput label,#dm .dm-layout-sec div.dmInner .dmform[data-layout="layout-2"] .dmforminput label{width:75px;vertical-align:top;white-space:normal}
                #dm .dmBody div.dmform[data-layout="layout-2"] .dmforminput:not(.g-recaptcha){-webkit-justify-content:flex-start!important;-ms-flex-pack:start!important;justify-content:flex-start!important}
                #dm .dm-layout-sec div.dmInner .dmform[data-layout="layout-1"] .dmforminput,#dm div.dmInner .dmform[data-layout="layout-1"] .dmforminput{display:block}
                #dm .dm-layout-sec div.dmInner .dmform[data-layout="layout-1"] .dmforminput>*:not(label):not(div),#dm div.dmInner .dmform[data-layout="layout-1"] .dmforminput>*:not(label):not(div){background:transparent;border:2px solid black;display:inline-block}
                #dm .dm-layout-sec div.dmInner .dmform[data-layout="layout-2"] .dmforminput,#dm div.dmInner .dmform[data-layout="layout-2"] .dmforminput{-js-display:flex;display:-webkit-flex;display:-ms-flexbox;display:flex}
                #dm .dm-layout-sec div.dmInner .dmform[data-layout="layout-2"] .dmforminput textarea,#dm div.dmInner .dmform[data-layout="layout-2"] .dmforminput>textarea,#dm .dm-layout-sec div.dmInner .dmform[data-layout="layout-2"] .dmforminput input:not([type=checkbox]):not([type=radio]),#dm div.dmInner .dmform[data-layout="layout-2"] .dmforminput>input{width:calc(100% - 80px)}
                #dm div.dmInner .dmform[data-layout="layout-2"] .dmforminput>.resizeHandler{height:100%;bottom:0}#dm .dm-layout-sec div.dmInner .dmform[data-layout="layout-3"] .dmforminput,#dm div.dmInner .dmform[data-layout="layout-3"] .dmforminput{margin-top:20px}
                #dm .dm-layout-sec div.dmInner .dmform[data-layout="layout-3"] .dmforminput>*:not(label):not(div),#dm div.dmInner .dmform[data-layout="layout-3"] .dmforminput>*:not(label):not(div){background:transparent;border:0;border-radius:0;-webkit-appearance:none;border-bottom:1px solid;height:30px}
                /**/#dm div.dmInner .dmform .dmforminput .radiowrapper span{line-height:normal}#dm div.dmInner .dmform .dmforminput .checkboxwrapper span,#dm div.dmInner .dmform .dmforminput .optinwrapper div{vertical-align:text-bottom;line-height:normal;display:inline-block}
                #dm div.dmInner .dmform .dmforminput .horizontal.radiowrapper span,#dm div.dmInner .dmform .dmforminput .horizontal.checkboxwrapper span,#dm div.dmInner .dmform .dmforminput .horizontal.optinwrapper div div{margin:0 15px 0 3px}
                #dm div.dmInner .dmform .dmforminput .horizontal{-js-display:flex;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-wrap:wrap;-ms-flex-wrap:wrap;flex-wrap:wrap}#dm div.dmInner .dmform[data-layout="layout-2"] .dmforminput .horizontal{-js-display:inline-flex;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex}
                #dm div.dmInner .dmform .dmforminput .horizontal div{-js-display:flex;display:-webkit-flex;display:-ms-flexbox;display:flex}#dm div.dmInner .dmform .dmforminput .horizontal input{-webkit-flex-shrink:0;-ms-flex-negative:0;flex-shrink:0;margin-top:.2em}
                #dm div.dmInner .dmform .dmforminput label[hide="true"]{display:none}/**/.dmform .inputError{outline:1px solid red!important}.dmform .dmforminput label{display:block;overflow:hidden;text-overflow:ellipsis}
                .dmMobileBody .dmform .dmforminput label{white-space:normal}.dmforminput.newLine{clear:both}.dmform .dmWidgetClear{clear:both;display:block}#dm .dmform.form-rtl-direction .dmform-title{text-align:right}
                #dm .dmform.form-rtl-direction label,#dm .dmform.form-rtl-direction .dmforminput input,#dm .dmform.form-rtl-direction textarea,#dm .dmform.form-rtl-direction .radiowrapper,#dm .dmform.form-rtl-direction .checkboxwrapper,#dm .dmform.form-rtl-direction .optinwrapper{direction:rtl;text-align:right}
                #dm .dmform.form-rtl-direction .radiowrapper,#dm .dmform.form-rtl-direction .checkboxwrapper,#dm .dmform.form-rtl-direction .optinwrapper,#dm .dmform.form-rtl-direction .fileUploadLink{float:right;clear:both}
                #dm .dmform.form-rtl-direction .dmRespDesignRow .dmRespDesignCol{float:right;text-align:right}#dm .dmform.form-rtl-direction .dmWidget.R{float:left}.u_dm .dmform a.fileUploadLink{text-decoration:underline;cursor:pointer}
                .dmform[data-layout='layout-2'] .checkboxwrapper,.dmform[data-layout='layout-2'] .radiowrapper,.dmform[data-layout='layout-2'] .optinwrapper{-webkit-justify-content:flex-start!important;-ms-flex-pack:start!important;justify-content:flex-start!important;text-align:left!important;text-overflow:unset}
                .dmform[data-layout='layout-2'] .dmforminput label{margin-right:5px}#dmRoot.dmLargeBody #dm .dmWidget.dmformsubmit{max-width:100%;padding:0}.dmLargeBody #dm .large-3 .dmformsubmit.dmWidget,.dmLargeBody #dm .large-4 .dmformsubmit.dmWidget{width:150px}
                .dmLargeBody #dm .large-5 .dmformsubmit.dmWidget,.dmLargeBody #dm .large-6 .dmformsubmit.dmWidget,.dmLargeBody #dm .large-7 .dmformsubmit.dmWidget,.dmLargeBody #dm .large-8 .dmformsubmit.dmWidget,.dmLargeBody #dm .large-9 .dmformsubmit.dmWidget,.dmLargeBody #dm .large-10 .dmformsubmit.dmWidget{width:200px}
                .dmLargeBody #dm .large-11 .dmformsubmit.dmformsubmit,.dmLargeBody #dm .large-12 .dmformsubmit.dmformsubmit{width:280px}.dmMobileBody #dm .dmRespRow .dmRespCol.small-12 .dmform-wrapper .dmformsubmit{width:91%;max-width:91%;padding:0 10px;float:left}
                .inFormLayoutMode .dmform.inlineEditorFormSelected .dmforminput{transition:all .1s linear}.dmform .dmforminput label{display:block;overflow:hidden;text-overflow:ellipsis}.dmMobileBody .dmform .dmforminput label{white-space:normal}
                .dmform .resizeHandler,.dmform .newLineButton{visibility:hidden}.dmform.inlineEditorFormSelected .resizeHandler{visibility:visible;height:calc(100% - 30px);position:absolute;bottom:5px;right:10px;cursor:col-resize;z-index:999}
                .dmform.inlineEditorFormSelected .newLineButton{visibility:visible;position:absolute;left:24px;bottom:calc(50% - 22px);padding:4px;cursor:pointer}.dmform.inlineEditorFormSelected .newLineButton:before{display:inline-block}
                .dmform.inlineEditorFormSelected .newLine .newLineButton:before{-webkit-transform:rotateZ(180deg)}.dmform.inlineEditorFormSelected .resizeHandler span{font-size:9px;position:relative;top:50%;margin-top:-4px;color:#666}
                .dmform.inlineEditorFormSelected .resizeHandler span.dm-icon-chevron-right{margin-left:4px}.dmform.inlineEditorFormSelected .large-1 .resizeHandler span.dm-icon-chevron-left{visibility:hidden}.dmform.inlineEditorFormSelected .large-12 .resizeHandler span.dm-icon-chevron-right{visibility:hidden}
                .dmform.inlineEditorFormSelected .resizeHandler .handle{width:2px;background-color:#666;height:100%;background:url(/editor/nee/images/common/2ColumnsArrows.png) no-repeat center 50%,url(/editor/nee/images/common/bluePic.png) repeat-y center;border-right:0;right:-5px;width:12px}/**//**/.style1.dmSocialFacebook,.style4.dmSocialFacebook{background:#5f82ce}.style1.dmSocialTwitter,.style4.dmSocialTwitter{background:#65cdef}.style1.dmSocialGooglePlus,.style4.dmSocialGooglePlus{background:#da4835}
                .style1.dmSocialInstagram,.style4.dmSocialInstagram{background:#c13584}.style1.dmSocialYoutube,.style4.dmSocialYoutube{background:#db3434}.style1.dmSocialLinkedin,.style4.dmSocialLinkedin{background:#1696dd}
                .style1.dmSocialYelp,.style4.dmSocialYelp{background:#e43340}.style1.dmSocialPinterest,.style4.dmSocialPinterest{background:#cb2038}.style1.dmSocialVimeo,.style4.dmSocialVimeo{background:#1ab7ea}.style1.dmSocialPicasa,.style4.dmSocialPicasa{background:#be81d1}
                .style1.dmSocialFoursquare,.style4.dmSocialFoursquare{background:#ef4b78}.style1.dmSocialRss,.style4.dmSocialRss{background:#f39200}.style1.dmSocialReddit,.style4.dmSocialReddit{background:#ff4500}.style1.dmSocialEmail,.style4.dmSocialEmail{background:#617379}
                .style1.dmSocialSnapchat,.style4.dmSocialSnapchat{background:#fffc00}.style1.dmSocialTripadvisor,.style4.dmSocialTripadvisor{background:#589442}.style1:after{content:"";width:44px;height:28px;display:block;position:absolute;top:0;left:0;z-index:-1;border-radius:10px}
                .style1.dmSocialFacebook:after{background:#7f9bd8}.style1.dmSocialTwitter:after{background:#84d7f2}.style1.dmSocialGooglePlus:after{background:#e16d5d}.style1.dmSocialInstagram:after{background:#d658b6}
                .style1.dmSocialYoutube:after{background:#e25d5d}.style1.dmSocialLinkedin:after{background:#45abe4}.style1.dmSocialYelp:after{background:#e95c66}.style1.dmSocialPinterest:after{background:#d54d60}.style1.dmSocialVimeo:after{background:#48c5ee}
                .style1.dmSocialPicasa:after{background:#cb9ada}.style1.dmSocialFoursquare:after{background:#f97b9d}.style1.dmSocialRss:after{background:#f5a833}.style1.dmSocialReddit:after{background:#ef6837}.style1.dmSocialEmail:after{background:#697a80}
                .style1.dmSocialSnapchat:after{background:#f3f174}.style1.dmSocialTripadvisor:after{background:#5da243}/**//**/.style2.dmSocialFacebook{color:#5f82ce}.style2.dmSocialTwitter{color:#65cdef}.style2.dmSocialGooglePlus{color:#da4835}
                .style2.dmSocialInstagram{color:#c13584}.style2.dmSocialYoutube{color:#db3434}.style2.dmSocialLinkedin{color:#1696dd}.style2.dmSocialYelp{color:#e43340}.style2.dmSocialPinterest{color:#cb2038}.style2.dmSocialVimeo{color:#1ab7ea}
                .style2.dmSocialPicasa{color:#be81d1}.style2.dmSocialFoursquare{color:#ef4b78}.style2.dmSocialRss{color:#f39200}.style2.dmSocialReddit{color:#ff4500}.style2.dmSocialEmail{color:#617379}.style2.dmSocialSnapchat{color:#fffc00}
                .style2.dmSocialTripadvisor{color:#589442}/**//**/.style6.dmSocialFacebook{background:#5f82ce}.style6.dmSocialTwitter{background:#65cdef}.style6.dmSocialGooglePlus{background:#da4835}.style6.dmSocialInstagram{background:#c13584}
                .style6.dmSocialYoutube{background:#db3434}.style6.dmSocialLinkedin{background:#1696dd}.style6.dmSocialYelp{background:#e43340}.style6.dmSocialPinterest{background:#cb2038}.style6.dmSocialVimeo{background:#1ab7ea}
                .style6.dmSocialPicasa{background:#be81d1}.style6.dmSocialFoursquare{background:#ef4b78}.style6.dmSocialRss{background:#f39200}.style6.dmSocialReddit{background:#ff4500}.style6.dmSocialEmail{background:#617379}
                .style6.dmSocialSnapchat{background:#fffc00}.style6.dmSocialTripadvisor{background:#589442}/**//**/.style7.dmSocialFacebook{background:#5f82ce;box-shadow:0 5px 0 0px #4b68a5}.style7.dmSocialTwitter{background:#65cdef;box-shadow:0 5px 0 0px #51a4bf}
                .style7.dmSocialGooglePlus{background:#da4835;box-shadow:0 5px 0 0px #c44130}.style7.dmSocialInstagram{background:#c13584;box-shadow:0 5px 0 0px #7d1b64}.style7.dmSocialYoutube{background:#db3434;box-shadow:0 5px 0 0px #b3392c}
                .style7.dmSocialLinkedin{background:#1696dd;box-shadow:0 5px 0 0px #1278b1}.style7.dmSocialYelp{background:#e43340;box-shadow:0 5px 0 0px #b62933}.style7.dmSocialPinterest{background:#cb2038;box-shadow:0 5px 0 0px #a21a2d}
                .style7.dmSocialVimeo{background:#1ab7ea;box-shadow:0 5px 0 0px #1592bb}.style7.dmSocialPicasa{background:#be81d1;box-shadow:0 5px 0 0px #9867a7}.style7.dmSocialFoursquare{background:#ef4b78;box-shadow:0 5px 0 0px #da3b67}
                .style7.dmSocialRss{background:#f39200;box-shadow:0 5px 0 0px #c27500}.style7.dmSocialReddit{background:#ff4500;box-shadow:0 5px 0 0px #ae5534}.style7.dmSocialEmail{background:#617379;box-shadow:0 5px 0 0px #475459}
                .style7.dmSocialSnapchat{background:#fffc00;box-shadow:0 5px 0 0px #d1d05d}.style7.dmSocialTripadvisor{background:#589442;box-shadow:0 5px 0 0px #4e7b3e}/**//**/body.dmMobileBody div[dmtemplateid]:not([dmtemplateid='SlideRightTopFloatM']) .dmHeader .multilingualWidget{
                position: absolute;
                top: 14px;
                left: 13px;
                margin-top: 0
            }
            body.dmMobileBody div[dmtemplateid][dmtemplateid='SlideRightTopFloatM'] .dmHeader .multilingualWidget {
                position: absolute;
                top: 5px;
                right: 17px
            }
            body.dmTabletBody #dm div[dmtemplateid='StandardLayoutMultiT'] .dmHeader .multilingualWidget {
                position: absolute !important;
                top: 5px !important;
                right: 17px !important;
                left: initial !important
            }
            body.dmMobileBody .dmHeader .displayHidden-inner .multilingualWidget {
                top: 0 !important
            }
            #hcontainer div.dmRespCol div.multilingualWidget, #dm_content div.dmRespCol div.multilingualWidget {
                width: auto !important;
                display: table !important
            }
            .multilingualWidget {
                clear: both;
                margin: 0;
                vertical-align: top;
                display: table !important;
                font-size: 0;
                font-family: sans-serif
            }
            .multilingualWidget.displayNone {
                display: none !important
            }
            .multilingualWidget > div {
                position: relative
            }
            .multilingualWidget .language {
                color: #888;
                display: inline-block
            }
            .multilingualWidget .language a {
                text-align: center;
                display: inline-block;
                color: inherit;
                border: #dadada 1px solid;
                background-color: #fff
            }
            .multilingualWidget .language a img {
                width: 24px;
                height: 26px;
                min-width: 24px;
                min-height: 26px
            }
            .multilingualWidget .language a span {
                display: none;
                line-height: initial
            }
            .multilingualWidget .language a span.name {
                margin-top: 5px;
                margin-left: 7px;
                font-size: 13px;
                font-weight: 400
            }
            .multilingualWidget .language a span.short-label {
                font-size: 13px
            }
            .multilingualWidget .language a:after {
                line-height: initial
            }
            .multilingualWidget.open .current-language a:after {
                -webkit-transform: rotate(-180deg);
                -ms-transform: rotate(-180deg);
                transform: rotate(-180deg)
            }
            .multilingualWidget .current-language a:after {
                transition: -webkit-transform .2s;
                transition: transform .2s;
                transition: transform .2s, -webkit-transform .2s
            }
            .multilingualWidget.dropdown .language {
                width: 100%
            }
            .multilingualWidget.dropdown .language a {
                display: block;
                padding: 1px 5px
            }
            .multilingualWidget.dropdown .other-languages {
                position: absolute;
                z-index: 800
            }
            .multilingualWidget.dropdown .other-languages a {
                border-top: 0 !important
            }
            .multilingualWidget.dropdown .current-language {
                position: relative
            }
            .multilingualWidget.dropdown .current-language span.name {
                padding-right: 25px
            }
            .multilingualWidget.dropdown .dm-icon {
                font-size: 9px;
                display: inline-block;
                position: absolute;
                top: 46%;
                -webkit-transform: translateY(-50%);
                -ms-transform: translateY(-50%);
                transform: translateY(-50%);
                transition: -webkit-transform .2s;
                transition: transform .2s;
                transition: transform .2s, -webkit-transform .2s;
                right: 8px
            }
            .multilingualWidget.dropdown.open .dm-icon {
                -webkit-transform: rotate(-180deg) translateY(50%);
                -ms-transform: rotate(-180deg) translateY(50%);
                transform: rotate(-180deg) translateY(50%)
            }
            .multilingualWidget.dropdown .other-languages {
                display: none
            }
            .multilingualWidget.dropdown.flag-only a {
                border: transparent 1px solid;
                background-color: transparent
            }
            .multilingualWidget.dropdown.flag-only.open .language a {
                background-color: rgba(0,0,0,0.3);
                border: #dadada 1px solid
            }
            .multilingualWidget.dropdown.flag-only .dm-icon {
                display: none
            }
            .multilingualWidget.dropdown.long-label a {
                text-align: left;
                padding: 2px 0 2px 5px;
                position: relative;
                box-sizing: border-box
            }
            .multilingualWidget.dropdown.long-label a span.name {
                display: inline-block
            }
            .multilingualWidget.dropdown.long-label.no-flag a {
                padding: 7px 10px 9px 10px
            }
            .multilingualWidget.dropdown.long-label.no-flag a span.name {
                margin: 0;
                display: inline-block
            }
            .multilingualWidget.dropdown.short-label.no-flag a {
                padding: 8px 22px 9px 10px;
                font-size: 13px;
                height: 32px;
                box-sizing: border-box
            }
            .multilingualWidget.dropdown.short-label.no-flag a span.short-label {
                margin: 0;
                display: inline-block
            }
            .multilingualWidget.dropdown.short-label.no-flag .current-language a:after {
                top: 12px
            }
            .multilingualWidget.no-flag a img {
                display: none
            }
            .multilingualWidget.short-label span.short-label {
                text-transform: uppercase
            }
            .multilingualWidget.inline span {
                display: none
            }
            .multilingualWidget.inline.flag-only a {
                padding: 2px 5px;
                height: 32px;
                box-sizing: border-box
            }
            .multilingualWidget.inline.flag-only .language {
                display: inline-block
            }
            .multilingualWidget.inline.flag-only .current-language a {
                box-shadow: inset 0 0px 8px 0 rgba(0,0,0,0.6);
                border-right: 0
            }
            .multilingualWidget.inline.flag-only .current-language a {
                border-right-width: 0 !important;
                border-right-color: transparent !important;
                border-right-style: none !important
            }
            .multilingualWidget.inline.flag-only .other-languages a:not(:last-child) {
                border-right-width: 0 !important;
                border-right-color: transparent !important;
                border-right-style: none !important
            }
            .multilingualWidget.inline.flag-only .dm-icon {
                display: none
            }
            .multilingualWidget.inline.short-label.no-flag span.short-label {
                display: inline-block
            }
            .multilingualWidget.inline.short-label.no-flag .dm-icon {
                display: none
            }
            .multilingualWidget.inline.short-label.no-flag .current-language a {
                padding-right: 0;
                border-right-width: 0 !important;
                border-right-color: transparent !important;
                border-right-style: none !important
            }
            .multilingualWidget.inline.short-label.no-flag .current-language a span.short-label {
                font-weight: bold
            }
            .multilingualWidget.inline.short-label.no-flag .other-languages a {
                border-left-color: transparent !important;
                border-left-width: 0 !important;
                border-left-style: none !important
            }
            .multilingualWidget.inline.short-label.no-flag .other-languages a:not(:last-child) {
                padding-right: 0;
                border-right-color: transparent !important;
                border-right-width: 0 !important;
                border-right-style: none !important
            }
            .multilingualWidget.inline.short-label.no-flag a {
                position: relative;
                padding: 8px 10px 8px 10px;
                font-size: 13px;
                height: 32px;
                text-decoration: none
            }
            .multilingualWidget.inline.short-label.no-flag a:after {
                content: "/";
                position: absolute;
                top: 8px;
                right: -7px;
                z-index: 1;
                pointer-events: none
            }
            .multilingualWidget.inline.short-label.no-flag a:hover .short-label {
                text-decoration: underline
            }
            .multilingualWidget.inline.short-label.no-flag .other-languages a:last-child:after {
                content: ""
            }
        </style>

        <!-- Site CSS -->
        <link type="text/css" rel="stylesheet" href="./Electronic Waves Home_files/661b5333962b49ba8fdfe2ded2230e5e_1.min.css" id="siteGlobalCss">

        <!-- additional css file per platform -->
        <link type="text/css" rel="stylesheet" href="./Electronic Waves Home_files/1and1-runtime.css">

        <style id="customWidgetStyle" type="text/css">
            .widget-85b0db .text, .widget-85b0db .image {
                display: inline;
            }

            .widget-85b0db .image {
                max-width: 100%;
                width: 200px;
            }
            .widget-85b0db .left {
                clear: left;
                float: left;
                margin-right: 10px;
            }
            .widget-85b0db .right {
                clear: right;
                float: right;
                margin-left: 10px;
            }

            .widget-85b0db .spacer-left {
                float: left;
            }

            .widget-85b0db .spacer-right {
                float: right;
            }

            #dm .widget-85b0db .wrapper, #dm .widget-85b0db .rteBlock {
                text-align: justify;
            }

            #dm .widget-85b0db ul, #dm .widget-85b0db ol {
                padding: 0;
                list-style-position: inside;
            }

            .widget-1f5975 .copyright {
                font-size: 13px;
                display: flex;
                text-align: left;
                justify-content: flex-start;
            }

        </style>
        <style id="innerPagesStyle" type="text/css">
        </style>

        <style id="additionalGlobalCss" type="text/css">
        </style>

        <!-- Page CSS -->
        <link type="text/css" rel="stylesheet" href="./Electronic Waves Home_files/661b5333962b49ba8fdfe2ded2230e5e_home_1.min.css" id="homeCssLink">

        <style id="pagestyle" type="text/css">
        </style>

        <style id="pagestyleDevice" type="text/css">
        </style>

        <!--[if IE 7]><style>.fw-head.fw-logo img{max-width: 290px;}.dm_header .logo-div img{max-width: 290px;}</style><![endif]-->
        <!--[if IE 8]><style>.fw-head .fw-logo img{max-width: 290px;}.dm_header .logo-div img{max-width: 290px;}*#dm div.dmHeader{_height:90px;min-height:0px;}</style><![endif]-->

        <!-- ========= JS Section ========= -->

        <!-- Modernizr -->
        <script>
            /* THIS FILE IS AUTO-GENERATED. SEE build/build-modernizr */

            /*! modernizr 3.5.0 (Custom Build) | MIT *
             * https://modernizr.com/download/?-cssvwunit-flexbox-flexboxlegacy-flexboxtweener-flexwrap-passiveeventlisteners-supports-svg-setclasses-cssclassprefix:dm- !*/! function(e, t, n) {
                function r(e, t) {
                    return typeof e === t
                }

                function s() {
                    var e,
                        t,
                        n,
                        s,
                        o,
                        i,
                        a;
                    for (var l in w)
                    if (w.hasOwnProperty(l)) {
                        if ( e = [],
                            t = w[l], t.name && (e.push(t.name.toLowerCase()), t.options && t.options.aliases && t.options.aliases.length))
                            for ( n = 0; n < t.options.aliases.length; n++)
                                e.push(t.options.aliases[n].toLowerCase());
                        for ( s = r(t.fn, "function") ? t.fn() : t.fn,
                        o = 0; o < e.length; o++)
                            i = e[o],
                            a = i.split("."), 1 === a.length ? Modernizr[a[0]] = s : (!Modernizr[a[0]] || Modernizr[a[0]] instanceof Boolean || (Modernizr[a[0]] = new Boolean(Modernizr[a[0]])), Modernizr[a[0]][a[1]] =
                            s), C.push(( s ? "" : "no-") + a.join("-"))
                    }
                }

                function o(e) {
                    var t = x.className,
                        n = Modernizr._config.classPrefix || "";
                    if (b && ( t = t.baseVal), Modernizr._config.enableJSClass) {
                        var r = new RegExp("(^|\\s)" + n + "no-js(\\s|$)");
                        t = t.replace(r, "$1" + n + "js$2")
                    }
                    Modernizr._config.enableClasses && (t += " " + n + e.join(" " + n), b ? x.className.baseVal = t : x.className = t)
                }

                function i(e, t) {
                    return !!~("" + e).indexOf(t)
                }

                function a() {
                    return "function" != typeof t.createElement ? t.createElement(arguments[0]) : b ? t.createElementNS.call(t, "http://www.w3.org/2000/svg", arguments[0]) : t.createElement.apply(t, arguments)
                }

                function l() {
                    var e = t.body;
                    return e || ( e = a( b ? "svg" : "body"), e.fake = !0), e
                }

                function f(e, n, r, s) {
                    var o,
                        i,
                        f,
                        u,
                        d = "modernizr",
                        p = a("div"),
                        c = l();
                    if (parseInt(r, 10))
                        for (; r--; )
                            f = a("div"), f.id = s ? s[r] : d + (r + 1), p.appendChild(f);
                    return o = a("style"), o.type = "text/css", o.id = "s" + d, (c.fake ? c : p).appendChild(o), c.appendChild(p), o.styleSheet ? o.styleSheet.cssText = e : o.appendChild(t.createTextNode(e)), p.id =
                    d, c.fake && (c.style.background = "", c.style.overflow = "hidden",
                    u = x.style.overflow, x.style.overflow = "hidden", x.appendChild(c)),
                    i = n(p, e), c.fake ? (c.parentNode.removeChild(c), x.style.overflow =
                    u, x.offsetHeight) : p.parentNode.removeChild(p), !!i
                }

                function u(e) {
                    return e.replace(/([A-Z])/g, function(e, t) {
                        return "-" + t.toLowerCase()
                    }).replace(/^ms-/, "-ms-")
                }

                function d(t, n, r) {
                    var s;
                    if ("getComputedStyle" in e) {
                        s = getComputedStyle.call(e, t, n);
                        var o = e.console;
                        if (null !== s)
                            r && ( s = s.getPropertyValue(r));
                        else if (o) {
                            var i = o.error ? "error" : "log";
                            o[i].call(o, "getComputedStyle returning null, its possible modernizr test results are inaccurate")
                        }
                    } else
                        s = !n && t.currentStyle && t.currentStyle[r];
                    return s
                }

                function p(t, r) {
                    var s = t.length;
                    if ("CSS" in e && "supports" in e.CSS) {
                        for (; s--; )
                            if (e.CSS.supports(u(t[s]), r))
                                return !0;
                        return !1
                    }
                    if ("CSSSupportsRule" in e) {
                        for (var o = []; s--; )
                            o.push("(" + u(t[s]) + ":" + r + ")");
                        return o = o.join(" or "), f("@supports (" + o + ") { #modernizr { position: absolute; } }", function(e) {
                            return "absolute" == d(e, null, "position")
                        })
                    }
                    return n
                }

                function c(e) {
                    return e.replace(/([a-z])-([a-z])/g, function(e, t, n) {
                        return t + n.toUpperCase()
                    }).replace(/^-/, "")
                }

                function v(e, t, s, o) {
                    function l() {
                        u && (
                        delete P.style,
                        delete P.modElem)
                    }

                    if ( o = r(o, "undefined") ? !1 : o, !r(s, "undefined")) {
                        var f = p(e, s);
                        if (!r(f, "undefined"))
                            return f
                    }
                    for (var u,
                        d,
                        v,
                        m,
                        g,
                        y = ["modernizr", "tspan", "samp"]; !P.style && y.length; )
                        u = !0, P.modElem = a(y.shift()), P.style = P.modElem.style;
                    for ( v = e.length,
                    d = 0; v > d; d++)
                        if ( m = e[d],
                        g = P.style[m], i(m, "-") && ( m = c(m)), P.style[m] !== n) {
                            if (o || r(s, "undefined"))
                                return l(), "pfx" == t ? m : !0;
                            try {
                                P.style[m] = s
                            } catch(h) {
                            }
                            if (P.style[m] != g)
                                return l(), "pfx" == t ? m : !0
                        }
                    return l(), !1
                }

                function m(e, t) {
                    return function() {
                        return e.apply(t, arguments)
                    }
                }

                function g(e, t, n) {
                    var s;
                    for (var o in e)
                    if (e[o] in t)
                        return n === !1 ? e[o] : ( s = t[e[o]], r(s, "function") ? m(s, n || t) : s);
                    return !1
                }

                function y(e, t, n, s, o) {
                    var i = e.charAt(0).toUpperCase() + e.slice(1),
                        a = (e + " " + T.join(i + " ") + i).split(" ");
                    return r(t, "string") || r(t, "undefined") ? v(a, t, s, o) : ( a = (e + " " + z.join(i + " ") + i).split(" "), g(a, t, n))
                }

                function h(e, t, r) {
                    return y(e, n, n, t, r)
                }

                var w = [],
                    S = {
                    _version : "3.5.0",
                    _config : {
                        classPrefix : "dm-",
                        enableClasses : !0,
                        enableJSClass : !0,
                        usePrefixes : !0
                    },
                    _q : [],
                    on : function(e, t) {
                        var n = this;
                        setTimeout(function() {
                            t(n[e])
                        }, 0)
                    },
                    addTest : function(e, t, n) {
                        w.push({
                            name : e,
                            fn : t,
                            options : n
                        })
                    },
                    addAsyncTest : function(e) {
                        w.push({
                            name : null,
                            fn : e
                        })
                    }
                },
                    Modernizr = function() {
                };
                Modernizr.prototype = S,
                Modernizr = new Modernizr;
                var C = [],
                    x = t.documentElement,
                    b = "svg" === x.nodeName.toLowerCase();
                Modernizr.addTest("svg", !!t.createElementNS && !!t.createElementNS("http://www.w3.org/2000/svg", "svg").createSVGRect);
                var _ = "Moz O ms Webkit",
                    T = S._config.usePrefixes ? _.split(" ") : [];
                S._cssomPrefixes = T;
                var E = {
                    elem : a("modernizr")
                };
                Modernizr._q.push(function() {
                    delete E.elem
                });
                var P = {
                    style : E.elem.style
                };
                Modernizr._q.unshift(function() {
                    delete P.style
                });
                var z = S._config.usePrefixes ? _.toLowerCase().split(" ") : [];
                S._domPrefixes = z, S.testAllProps =
                y, S.testAllProps =
                h, Modernizr.addTest("flexbox", h("flexBasis", "1px", !0)), Modernizr.addTest("flexboxlegacy", h("boxDirection", "reverse", !0)), Modernizr.addTest("flexboxtweener", h("flexAlign", "end", !0)), Modernizr.addTest("flexwrap", h("flexWrap", "wrap", !0));
                var N = "CSS" in e && "supports" in e.CSS,
                    j = "supportsCSS" in e;
                Modernizr.addTest("supports", N || j);
                var A = S.testStyles = f;
                A("#modernizr { width: 50vw; }", function(t) {
                    var n = parseInt(e.innerWidth / 2, 10),
                        r = parseInt(d(t, null, "width"), 10);
                    Modernizr.addTest("cssvwunit", r == n)
                }), Modernizr.addTest("passiveeventlisteners", function() {
                    var t = !1;
                    try {
                        var n = Object.defineProperty({}, "passive", {
                            get : function() {
                                t = !0
                            }
                        });
                        e.addEventListener("test", null, n)
                    } catch(r) {
                    }
                    return t
                }), s(), o(C),
                delete S.addTest,
                delete S.addAsyncTest;
                for (var k = 0; k < Modernizr._q.length; k++)
                    Modernizr._q[k]();
                e.Modernizr = Modernizr
            }(window, document);
        </script>

        <script>
            var isWLR = true;
        </script>
        <!-- Custom Widgets js functions map -->
        <script>
            window.customWidgetsFunctions = {};
            window.customWidgetsStrings = {};
        </script>
        <script>
            window.customWidgetsFunctions["1b70982e7b474a1dbfcdcb76432af84d~4"] = function(element, data, api) {
                if (data.inEditor && !data.config.gcalendar_email) {
                    $(element).prepend('<p class="widget-google-calendar-1and1-placeholder">' + api.localize('gcalendar.widget.html.editor_text', 'Please enter a calendar ID for the widget to render the preview available.') + '</p>');
                }

                $('a.widget-google-calendar-1and1-popup').click(function() {
                    myWindow = window.open($(this, element).attr("href"), "Google calendar", "width=800,height=600,scrollbars=yes,status=yes,titlebar=yes");
                    return false;
                });
            };
        </script>
        <script type="text/javascript">
            var version = "3.9.2";
            var build = "2019-04-10T09_16_45";

            function buildEditorParent() {
                window.isMultiScreen = true;
                window.editorParent = {};
                window.previewParent = {};
                window.assetsCacheQueryParam = "?version=2019-04-10T09_16_45";
                try {
                    var _p = window.parent;
                    if (_p && _p.document && _p.$ && _p.$.dmfw) {
                        window.editorParent = _p;
                    } else if (_p.isSitePreview) {
                        window.previewParent = _p;
                    }
                } catch (e) {

                }
            }

            buildEditorParent();

        </script>
        <!-- Load jQuery -->
        <script type="text/javascript" src="./Electronic Waves Home_files/jquery.min.js.download"></script>
        <!-- End Load jQuery -->
        <script>
            window.cookiesNotificationMarkupPreview = ' <div>In order to provide you with the best online experience this website uses cookies. By using our website, you agree to our use of cookies. <a href=\"\/privacy\" target=\"_blank\">More Info<\/a>.<\/div> \n';
        </script>
        <!-- HEAD RT JS Include -->
        <script>
            window.INSITE = window.INSITE || {};
            window.INSITE.device = "desktop";
            window.rtCommonProps = {};
            rtCommonProps["rt.ajax.ajaxScriptsFix"] = true;
            rtCommonProps["rt.pushnotifs.sslframe.encoded"] = 'aHR0cHM6Ly97c3ViZG9tYWlufS5wdXNoLW5vdGlmcy5jb20=';
            rtCommonProps["facebook.accessToken"] = '126515034112906|8vv7JhnEegS8qz43fIOZjxGZReA';
            rtCommonProps["performance.tabletPreview.removeScroll"] = 'false';
            rtCommonProps["feature.flag.contactUsNewForm"] = 'true';
            rtCommonProps["inlineEditGrid.snap"] = true;
            rtCommonProps["popup.insite.cookie.ttl"] = '0.0';
            rtCommonProps["rt.pushnotifs.force.button"] = true;
            rtCommonProps["google.places.key"] = 'AIzaSyBAwUOqPUB1CU31yDztoZYaUE7sPv4ktEI';
            rtCommonProps["common.mapbox.token"] = 'pk.eyJ1IjoiZGFubnliMTIzIiwiYSI6ImNqMGljZ256dzAwMDAycXBkdWxwbDgzeXYifQ.Ck5P-0NKPVKAZ6SH98gxxw';
            rtCommonProps["common.mapbox.js.override"] = false;
            rtCommonProps["common.opencage.token"] = '319e14f32bcce967ba55cd263478796d';
            rtCommonProps["common.here.appId"] = 'iYvDjIQ2quyEu0rg0hLo';
            rtCommonProps["common.here.appCode"] = '1hcIxLJcbybmtBYTD9Z1UA';
            rtCommonProps["isCoverage.test"] = false;
            rtCommonProps["ecommerce.ecwid.script"] = 'https://app.multiscreenstore.com/script.js';
            rtCommonProps["feature.flag.mappy.kml"] = false;
            rtCommonProps["feature.flag.lazy.photoGallery"] = false;

            rtCommonProps["common.mapsProvider"] = 'mapbox';
            rtCommonProps['common.mapsProvider.version'] = '0.52.0';
            rtCommonProps["common.geocodeProvider"] = 'here';
            rtCommonProps['common.map.defaults.radiusSize'] = '1500';
            rtCommonProps['common.map.defaults.radiusBg'] = 'rgba(255, 255, 255, 0.4)';
            rtCommonProps['common.map.defaults.strokeColor'] = 'rgba(255, 255, 255, 1)';
            rtCommonProps['common.map.defaults.strokeSize'] = '2';
            rtCommonProps['server.for.resources'] = '';
            rtCommonProps["feature.flag.lazy.widgets"] = false;

        </script>
        <script src="./Electronic Waves Home_files/d-js-runtime-one-package.min.js.download"></script>
        <!-- End of HEAD RT JS Include -->
        <script src="./Electronic Waves Home_files/d-js-one-runtime-layouts-package.min.js.download"></script>
        <script src="./Electronic Waves Home_files/d-js-one-runtime-layouts-desktop.min.js.download"></script>
        <script>
            jQuery.DM.updateWidthAndHeight();
            $(window).resize(function() {
                jQuery.DM.updateWidth();

            });
            $(window).bind("orientationchange", function(e) {
                jQuery.DM.updateWidth();
                jQuery.layoutManager.initLayout();

            });
            $(document).resize(function() {
                jQuery.DM.updateWidth();

            });
        </script>

        <!-- End render the required css and JS in the head section -->

        <title> Electronic Waves Home </title>
        <meta name="keywords" content="Internet,Radio,Station,Dance Music,D.J&amp;#39;s">
        <meta name="description" content="On the home page you will find the media player to listen to your favourite tunes also the social media feeds and a description of the station.Includes live whats on feed">

        <meta name="twitter:card" content="summary">
        <meta name="twitter:title" content="Electronic Waves Home">
        <meta name="twitter:description" content="On the home page you will find the media player to listen to your favourite tunes also the social media feeds and a description of the station.Includes live whats on feed">
        <meta name="twitter:image:src" content="https://cdn.website-editor.net/661b5333962b49ba8fdfe2ded2230e5e/dms3rep/multi/IMG_0096.PNG">
        <meta property="og:description" content="On the home page you will find the media player to listen to your favourite tunes also the social media feeds and a description of the station.Includes live whats on feed">
        <meta property="og:title" content="Electronic Waves Home">
        <meta property="og:image" content="https://cdn.website-editor.net/661b5333962b49ba8fdfe2ded2230e5e/dms3rep/multi/IMG_0096.PNG">

        <!-- SYS- MUFORDFfRVVfUFJPRA== -->

        <link rel="stylesheet" type="text/css" href="./Electronic Waves Home_files/currenttrack.css">
        <script src="./Electronic Waves Home_files/snippet.js.download"></script>
        <link rel="stylesheet" type="text/css" id="mapbox-gl-css" href="./Electronic Waves Home_files/mapbox-gl.css">
        <style id="mapbox-internal-css">
            .marker.mapboxgl-marker {
                margin-top: -20px;
                width: 25px;
                height: 41px;
                z-index: 100;
                display: block;
                background-image: url('/editor/ed/vendor/leaflet/images/marker-icon.png');
            }
        </style>
        <style type="text/css">
            .dm-google-calendar .calendar-container {
                display: -ms-flexbox;
                display: flex;
                -ms-flex-direction: column;
                flex-direction: column;
                height: 100%;
            }
            .dm-google-calendar .calendar-container .navigation-header {
                height: 50px;
                display: -ms-flexbox;
                display: flex;
                -ms-flex-pack: justify;
                justify-content: space-between;
            }
            .dm-google-calendar .calendar-container .navigation-header .month-navigation {
                display: -ms-flexbox;
                display: flex;
                font-size: 24px;
            }
            .dm-google-calendar .calendar-container .navigation-header .month-navigation .month-year-container {
                font-size: 26px;
                font-weight: bold;
                margin: 0 10px;
            }
            .dm-google-calendar .calendar-container .navigation-header .calendar-view-navigation {
                display: -ms-flexbox;
                display: flex;
            }
            .dm-google-calendar .calendar-container .navigation-header .calendar-view-navigation > * {
                margin: 0 5px;
            }
            .dm-google-calendar .calendar-container .navigation-header .calendar-view-navigation .month-btn-selected {
                font-weight: bold;
            }
            .dm-google-calendar .calendar-container .navigation-header .calendar-view-navigation .week-btn-selected {
                font-weight: bold;
            }
            .dm-google-calendar .calendar-container .navigation-header .calendar-view-navigation .list-btn-selected {
                font-weight: bold;
            }
            .dm-google-calendar .calendar-container .week-day-names-header {
                display: -ms-flexbox;
                display: flex;
            }
            .dm-google-calendar .calendar-container .week-day-names-header .day-name {
                -ms-flex: 1 1 0%;
                flex: 1 1 0%;
                height: 50px;
                text-align: center;
            }
            .dm-google-calendar .calendar-container .weeks-container {
                -ms-flex: 1 1 0%;
                flex: 1 1 0%;
                display: -ms-flexbox;
                display: flex;
                -ms-flex-direction: column;
                flex-direction: column;
            }
            .dm-google-calendar .calendar-container .weeks-container .week-container {
                -ms-flex: 1 1 0%;
                flex: 1 1 0%;
                display: -ms-flexbox;
                display: flex;
            }
            .dm-google-calendar .calendar-container .weeks-container .week-container .monthly-day-card {
                width: 10px;
                background-color: #f8f8f8;
                border: 2px solid #ffffff;
                -ms-flex: 1 1 0%;
                flex: 1 1 0%;
                text-align: right;
                line-height: 0px;
            }
            .dm-google-calendar .calendar-container .weeks-container .week-container .monthly-day-card .day-of-month-container {
                display: inline-block;
                margin: 5px 5px;
                border-radius: 13px;
                width: 26px;
                height: 26px;
                text-align: center;
                vertical-align: middle;
                line-height: 26px;
                font-family: Montserrat;
                font-size: 13px;
            }
            .dm-google-calendar .calendar-container .weeks-container .week-container .monthly-day-card .day-of-month-container.today {
                background-color: red;
            }
            .dm-google-calendar .calendar-container .weeks-container .week-container .monthly-day-card .day-of-month-container .day-of-month-text {
                color: #8a888a;
            }
            .dm-google-calendar .calendar-container .weeks-container .week-container .monthly-day-card .day-of-month-container .day-of-month-text.today {
                color: #ffffff;
            }
            .dm-google-calendar .calendar-container .weeks-container .week-container .monthly-day-card .day-of-month-container .not-day-of-month-text {
                color: #cccccc;
            }
            .dm-google-calendar .calendar-container .weeks-container .week-container .monthly-day-card .event-container {
                line-height: normal;
                text-align: left;
                font-size: 12px;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            .dm-google-calendar .calendar-container .weeks-container .week-container .monthly-day-card .event-container .start {
                font-weight: bold;
            }

            .dm-google-calendar .dmMobileBody .navigation-header {
                -ms-flex-pack: center;
                justify-content: center;
            }
            .dm-google-calendar .dmMobileBody .navigation-header .month-navigation {
                display: -ms-flexbox;
                display: flex;
                font-size: 24px;
            }
            .dm-google-calendar .dmMobileBody .navigation-header .month-navigation .month-year-container {
                font-size: 26px;
                font-weight: bold;
                margin: 0 10px;
            }
            .dm-google-calendar .dmMobileBody .navigation-header .calendar-view-navigation {
                display: -ms-flexbox;
                display: flex;
            }
            .dm-google-calendar .dmMobileBody .navigation-header .calendar-view-navigation > * {
                margin: 0 5px;
            }
            .dm-google-calendar .dmMobileBody .navigation-header .calendar-view-navigation .month-btn-selected {
                font-weight: bold;
            }
            .dm-google-calendar .dmMobileBody .navigation-header .calendar-view-navigation .week-btn-selected {
                font-weight: bold;
            }
            .dm-google-calendar .dmMobileBody .navigation-header .calendar-view-navigation .list-btn-selected {
                font-weight: bold;
            }

            .dm-google-calendar .dmMobileBody .week-day-names-header .day-name {
                height: 25px;
                font-size: 12px;
                font-weight: bold;
            }

            .dm-google-calendar .dmMobileBody .weeks-container {
                display: block;
            }
            .dm-google-calendar .dmMobileBody .weeks-container .week-container .monthly-day-card {
                height: 14.28 vw;
            }
            .dm-google-calendar .dmMobileBody .weeks-container .week-container .monthly-day-card .day-of-month-container {
                margin: 2px 3px;
                border-radius: 7px;
                width: 14px;
                height: 14px;
                line-height: 14px;
                font-size: 8px;
            }
        </style>
        <style type="text/css">
            .dmCountdown {
                -ms-flex-pack: center;
                justify-content: center;
                text-align: center;
                height: auto;
                margin: 0 auto;
            }
            .dmCountdown .countdown {
                padding: 2px;
            }
            .dmCountdown .container {
                display: -ms-flexbox;
                display: flex;
                width: 100%;
                height: auto;
            }
            .dmCountdown .tile {
                position: relative;
                line-height: normal;
                -ms-flex: 1 1 auto;
                flex: 1 1 auto;
            }
            .dmCountdown .label-tile {
                position: relative;
                -ms-flex: 1 0 0%;
                flex: 1 0 0%;
                height: 100%;
            }
            .dmCountdown .tile:after {
                content: '';
                display: block;
                padding-top: 100%;
            }
            .dmCountdown .divider {
                display: -ms-flexbox;
                display: flex;
                -ms-flex-align: center;
                align-items: center;
                -ms-flex-pack: center;
                justify-content: center;
                -ms-flex: 0 1 auto;
                flex: 0 1 auto;
                margin: 12px;
                color: #313131;
            }
            .dmCountdown .number {
                position: absolute;
                display: -ms-flexbox;
                display: flex;
                width: 100%;
                height: 100%;
                -ms-flex-align: center;
                align-items: center;
                -ms-flex-pack: center;
                justify-content: center;
                top: 0;
                left: 0;
            }
            .dmCountdown .label {
                display: -ms-flexbox;
                display: flex;
                width: 100%;
                -ms-flex-align: center;
                align-items: center;
                -ms-flex-pack: center;
                justify-content: center;
            }
            .dmCountdown .title {
                text-align: center !important;
                margin-top: 0;
            }
            .dmCountdown .countdown-message {
                margin-top: 20px;
                display: none;
            }
            .dmCountdown .countdown-message p {
                text-align: center !important;
            }
            .dmCountdown .divider.hidden {
                visibility: hidden !important;
                text-decoration: none !important;
                line-height: 0;
            }
            .dmCountdown[data-layout="layout-1"] {
                width: 600px;
            }
            .dmCountdown[data-layout="layout-1"] .number {
                background-color: transparent;
                box-shadow: none;
                font-weight: normal;
                font-size: 42px;
                color: #101010;
            }
            .dmCountdown[data-layout="layout-1"] .label {
                font-size: 16px;
                padding-top: 5px;
            }
            .dmCountdown[data-layout="layout-1"] .divider {
                visibility: hidden;
                margin: 0 12px;
            }
            .dmCountdown[data-layout="layout-1"] .tile-circle {
                stroke-dashoffset: 0;
            }
            .dmCountdown[data-layout="layout-2"] {
                width: 586px;
            }
            .dmCountdown[data-layout="layout-2"] .number {
                font-size: 42px;
                color: #fff;
                background-color: #000;
                font-weight: normal;
                border-radius: 5%;
                box-shadow: none;
            }
            .dmCountdown[data-layout="layout-2"] .label {
                font-size: 16px;
                padding-top: 10px;
                color: #b9b9b9;
            }
            .dmCountdown[data-layout="layout-2"] .divider {
                font-size: 42px;
                margin: 0 12px;
            }
            .dmCountdown[data-layout="layout-3"] {
                width: 586px;
            }
            .dmCountdown[data-layout="layout-3"] .number {
                font-size: 42px;
                color: #000000;
                background-color: #ffffff;
                border-radius: 5%;
                box-shadow: 0 8px 20px 0 rgba(73, 73, 73, 0.25);
                font-weight: normal;
            }
            .dmCountdown[data-layout="layout-3"] .label {
                font-size: 16px;
                padding-top: 10px;
                color: #b9b9b9;
            }
            .dmCountdown[data-layout="layout-3"] .divider {
                font-size: 42px;
                margin: 0 12px;
                visibility: hidden;
            }
            .dmCountdown[data-layout="layout-4"] {
                width: 586px;
            }
            .dmCountdown[data-layout="layout-4"] .number {
                font-size: 60px;
                color: #313131;
                background-color: transparent;
                box-shadow: none;
                height: 100%;
                width: 100%;
            }
            .dmCountdown[data-layout="layout-4"] .label {
                font-size: 16px;
                color: #b9b9b9;
            }
            .dmCountdown[data-layout="layout-4"] .divider {
                font-size: 60px;
                margin: 0 12px;
            }
            .dmCountdown[data-layout="layout-4"] .tile:after {
                padding-top: 0;
            }

            .dmMobileBody .dmCountdown .number {
                font-size: 22.5px;
            }

            .dmMobileBody .dmCountdown .label {
                padding-top: 3px;
                font-size: 12px;
            }

            .dmMobileBody .dmCountdown .divider {
                margin: 0 4px;
                font-size: 22px;
            }

            .dmMobileBody .dmCountdown[data-layout="layout-1"] .divider {
                margin: 0 2px;
                font-size: 19px;
            }

            .dmMobileBody .dmCountdown[data-layout="layout-2"] .divider {
                margin: 0 5px;
                font-size: 22px;
            }

            .dmMobileBody .dmCountdown[data-layout="layout-2"] .label {
                padding-top: 6px;
            }

            .dmMobileBody .dmCountdown[data-layout="layout-3"] .divider {
                margin: 0 2px;
            }

            .dmMobileBody .dmCountdown[data-layout="layout-3"] .label {
                padding-top: 6px;
            }

            .dmMobileBody .dmCountdown[data-layout="layout-3"] .number {
                font-size: 28px;
            }
        </style><script type="text/javascript" charset="utf-8" async="" src="./Electronic Waves Home_files/runtime-shared-parts-a-runtime.a9d151d9dd6a551590ff.js.download"></script><script type="text/javascript" charset="utf-8" async="" src="./Electronic Waves Home_files/2.06aff77e3fb082179a02.js.download"></script><script src="./Electronic Waves Home_files/perfbar.js.download" type="text/javascript"></script><script src="./Electronic Waves Home_files/22728.js.download" type="text/javascript"></script><script charset="utf-8" src="./Electronic Waves Home_files/moment_timeline_tweet.6e5b62723488aee38af0c77681396a5b.js.download"></script><script charset="utf-8" src="./Electronic Waves Home_files/timeline.4c6ab682148a0366f9efb1647a3f4799.js.download"></script>
    </head>

    <body id="dmRoot" class="supportsFontIcons supportsFontIcons dmRoot dmDesktopBody fix-mobile-scrolling dmResellerSite dmLargeBody  pcCustomScrollbar d1SiteBody dmBodyNoIscroll fullyLoaded" style="padding: 0px; margin: 0px; min-width: 1583px;">

        <div id="disabledImageZone" style="display:none;z-index:-1">
            <style type="text/css">
                #imageZone {
                    position: absolute;
                    margin: auto;
                }

                .coloumns {
                    border-radius: 3px;
                    background-color: rgb(249, 152, 13); /*border:1px solid #999;*/
                    height: 18px;
                    width: 6px;
                    -webkit-animation-name: loader;
                    -webkit-animation-duration: 1s;
                    -webkit-animation-iteration-count: infinite;
                    -webkit-animation-direction: linear;
                    -moz-animation-name: loader;
                    -moz-animation-duration: 1s;
                    -moz-animation-iteration-count: infinite;
                    -moz-animation-direction: linear;
                    opacity: .25;
                    -webkit-transform: scale(0.7);
                    -webkit-transform-origin: 50% 180%;
                    -moz-transform: scale(0.7);
                    -moz-transform-origin: 50% 180%;
                    position: absolute;
                }

                #coloumn1 {
                    -webkit-transform: rotate(0deg);
                    -webkit-animation-delay: -.914s;
                    -moz-transform: rotate(0deg);
                    -moz-animation-delay: -.914s;
                }

                #coloumn2 {
                    -webkit-transform: rotate(30deg);
                    -webkit-animation-delay: -.831s;
                    -moz-transform: rotate(30deg);
                    -moz-animation-delay: -.831s;
                }

                #coloumn3 {
                    -webkit-transform: rotate(60deg);
                    -webkit-animation-delay: -.747s;
                    -moz-transform: rotate(60deg);
                    -moz-animation-delay: -.747s;
                }

                #coloumn4 {
                    -webkit-transform: rotate(90deg);
                    -webkit-animation-delay: -.664s;
                    -moz-transform: rotate(90deg);
                    -moz-animation-delay: -.664s;
                }

                #coloumn5 {
                    -webkit-transform: rotate(120deg);
                    -webkit-animation-delay: -.581s;
                    -moz-transform: rotate(120deg);
                    -moz-animation-delay: -.581s;
                }

                #coloumn6 {
                    -webkit-transform: rotate(150deg);
                    -webkit-animation-delay: -.498s;
                    -moz-transform: rotate(150deg);
                    -moz-animation-delay: -.498s;
                }

                #coloumn7 {
                    -webkit-transform: rotate(180deg);
                    -webkit-animation-delay: -.415s;
                    -moz-transform: rotate(180deg);
                    -moz-animation-delay: -.415s;
                }

                #coloumn8 {
                    -webkit-transform: rotate(210deg);
                    -webkit-animation-delay: -.332s;
                    -moz-transform: rotate(210deg);
                    -moz-animation-delay: -.332s;
                }

                #coloumn9 {
                    -webkit-transform: rotate(240deg);
                    -webkit-animation-delay: -.249s;
                    -moz-transform: rotate(240deg);
                    -moz-animation-delay: -.249s;
                }

                #coloumn10 {
                    -webkit-transform: rotate(270deg);
                    -webkit-animation-delay: -.166s;
                    -moz-transform: rotate(270deg);
                    -moz-animation-delay: -.166s;
                }

                #coloumn11 {
                    -webkit-transform: rotate(300deg);
                    -webkit-animation-delay: -.083s;
                    -moz-transform: rotate(300deg);
                    -moz-animation-delay: -.083s;
                }

                #coloumn12 {
                    -webkit-transform: rotate(330deg);
                    -moz-transform: rotate(330deg);
                }

                @-webkit-keyframes loader {
                0% {
                opacity: 1;
                }
                100% {
                opacity: .25;
                }
                }

                @-moz-keyframes loader {
                0% {
                opacity: 1;
                }
                100% {
                opacity: .25;
                }
                }
            </style>
            <div id="imageZone">
                <div id="coloumn1" class="coloumns"></div>
                <div id="coloumn2" class="coloumns"></div>
                <div id="coloumn3" class="coloumns"></div>
                <div id="coloumn4" class="coloumns"></div>
                <div id="coloumn5" class="coloumns"></div>
                <div id="coloumn6" class="coloumns"></div>
                <div id="coloumn7" class="coloumns"></div>
                <div id="coloumn8" class="coloumns"></div>
                <div id="coloumn9" class="coloumns"></div>
                <div id="coloumn10" class="coloumns"></div>
                <div id="coloumn11" class="coloumns"></div>
                <div id="coloumn12" class="coloumns"></div>
            </div>
        </div>

        <!-- ========= Site Content ========= -->
        <div id="dm" class="dmwr">

            <div class="dm_wrapper standard-var5 widgetStyle-3 standard">
                <div dmwrapped="true" id="1901957768" class="dm-home-page" themewaschanged="true">
                    <div dmtemplateid="StandardLayoutMultiD" class="standardHeaderLayout dm-bfs dm-layout-home hasAnimations inMiniHeaderMode hasStickyHeader dmPageBody dmFreeHeader d-page-1716942098 runtime-module-container" id="dm-outer-wrapper" data-page-class="1716942098" data-buttonstyle="ROUND_SIDES" data-soch="true" data-background-size="cover" data-background-attachment="fixed" data-background-repeat="no-repeat" data-background-position="50% 0%" data-background-hide-inner="true" data-background-fullbleed="false" data-background-parallax-selector=".dmSectionParallex" data-background-parallax-speed="0.2">
                        <div id="dmStyle_outerContainer" class="dmOuter">
                            <div id="dmStyle_innerContainer" class="dmInner" style="min-height: 795px;">
                                <div class="dmLayoutWrapper standard-var dmStandardDesktop">
                                    <ul class="dmn dmLayoutNav hiddenNavPlaceHolder navPlaceHolder dmDisplay_None"></ul>
                                    <div>
                                        <div id="iscrollBody">
                                            <div id="site_content">
                                                <div class="dmHeaderContainer fHeader d-header-wrapper">
                                                    <div id="hcontainer" class="u_hcontainer dmHeader p_hfcontainer" freeheader="true" layout="78f5c343822e4eb3aac27f4ad5d13812===header" has-shadow="true" data-scrollable-target="body" data-scrollable-target-threshold="1" data-scroll-responder-id="1" logo-size-target="100%">
                                                        <div dm:templateorder="85" class="dmHeaderResp dmHeaderStack noSwitch" id="1709005236">
                                                            <div class="u_1150249187 dmRespRow dmDefaultListContentRow fullBleedChanged fullBleedMode mini-header-show-row" style="text-align:center" id="1150249187">
                                                                <div class="dmRespColsWrapper" id="1142333100">
                                                                    <div class="u_1262350822 small-12 dmRespCol large-4 medium-4 has-one-widget-only" id="1262350822">
                                                                        <div class="u_1288753361 imageWidget align-center" editablewidget="true" data-widget-type="image" id="1288753361" data-element-type="image"><img src="./Electronic Waves Home_files/IMG_0096.PNG" id="1835821841" class="" data-dm-image-path="https://cdn.website-editor.net/661b5333962b49ba8fdfe2ded2230e5e/dms3rep/multi/desktop/IMG_0096.PNG" data-dm-multi-sug-width="960" onerror="handleImageLoadError(this)">
                                                                        </div>
                                                                    </div>
                                                                    <div class="dmRespCol large-4 medium-4 small-12 has-more-one-widget" id="1436406339">
                                                                        <h1 class="dmNewParagraph" data-element-type="paragraph" id="1916863840" style="transition: opacity 1s ease-in-out 0s;" data-uialign="center">
                                                                        <div style="text-align: center;">
                                                                            <span style="color: rgb(0, 255, 0); font-size: 36px;">Electronic Waves Radio</span>
                                                                        </div>
                                                                        <div style="text-align: center;">
                                                                            <font color="#00ff00">
                                                                                <br>
                                                                            </font>
                                                                        </div></h1>
                                                                        <div class="align-center text-align-center dmSocialHub" id="1199706233" dmle_extension="social_hub" data-element-type="social_hub" wr="true" networks="" icon="true" surround="true" adwords="">
                                                                            <div class="socialHubWrapper">
                                                                                <div class="socialHubInnerDiv ">
                                                                                    <a href="https://facebook.com/306767830027958" target="_blank" dmle_dont_remove="target" dm_dont_rewrite_url="true"> <span class="dmSocialFacebook dm-icon-facebook oneIcon socialHubIcon style1" data-hover-effect=""></span> </a>
                                                                                    <a href="https://twitter.com/ElectronicWave5" target="_blank" dmle_dont_remove="target" dm_dont_rewrite_url="true"> <span class="dmSocialTwitter dm-icon-twitter oneIcon socialHubIcon style1" data-hover-effect=""></span> </a>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="u_1892655445 dmRespCol small-12 large-4 medium-4 has-one-widget-only" id="1892655445">
                                                                        <nav class="u_1131041222 effect-text-color main-navigation unifiednav dmLinksMenu" role="navigation" layout-main="horizontal_nav_layout_1" layout-sub="submenu_horizontal_1" data-show-vertical-sub-items="HOVER" id="1131041222" dmle_extension="onelinksmenu" data-element-type="onelinksmenu" wr="true" data-logo-src="https://cdn.website-editor.net/661b5333962b49ba8fdfe2ded2230e5e/dms3rep/multi/desktop/IMG_0096.PNG" data-nav-structure="HORIZONTAL" icon="true" surround="true" adwords="" data-from-nav="true" data-sub-nav="true" data-items="-1" custom-li-class="" custom-ul-class="" custom-a-class="" custom-inner-ul-class="" custom-nested-inner-ul-class="" custom-span-class="" navigation-id="unifiedNav" data-links-level="0" is-build-your-own="false">
                                                                            <ul class="unifiednav__container  ">
                                                                                <li class="unifiednav__item-wrap">
                                                                                    <a href="https://www.electronicwavesradio.com/" class="unifiednav__item   dmUDNavigationItem_00 currentPage dmNavItemSelected" target="" data-target-page-alias=""> <span class="nav-item-text " data-link-text="

                                                                                    Welcome To Electronic Waves Radio

                                                                                    ">Welcome To Electronic Waves Radio<span class="icon icon-angle-down"></span> </span> </a>
                                                                                </li>
                                                                                <li class="unifiednav__item-wrap">
                                                                                    <a href="https://www.electronicwavesradio.com/listen-live" class="unifiednav__item  dmUDNavigationItem_010101450968" target="" data-target-page-alias=""> <span class="nav-item-text " data-link-text="

                                                                                    Listen Live

                                                                                    ">Listen Live<span class="icon icon-angle-down"></span> </span> </a>
                                                                                </li>
                                                                                <li class="unifiednav__item-wrap">
                                                                                    <a href="https://www.electronicwavesradio.com/DJs" class="unifiednav__item  dmUDNavigationItem_010101783271" target="" data-target-page-alias=""> <span class="nav-item-text " data-link-text="

                                                                                    Electronic Waves Disc Jockeys

                                                                                    ">Electronic Waves Disc Jockeys<span class="icon icon-angle-down"></span> </span> </a>
                                                                                </li>
                                                                                <li class="unifiednav__item-wrap">
                                                                                    <a href="https://www.electronicwavesradio.com/directories-and-providers" class="unifiednav__item  dmUDNavigationItem_01010139232" target="" data-target-page-alias=""> <span class="nav-item-text " data-link-text="

                                                                                    Directories And Providers

                                                                                    ">Directories And Providers<span class="icon icon-angle-down"></span> </span> </a>
                                                                                </li>
                                                                            </ul>
                                                                        </nav>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="stickyHeaderSpacer" id="stickyHeaderSpacer" data-new="true"></div>
                                                <div class="dmRespRow dmRespRowStable dmRespRowNoPadding dmPageTitleRow ">
                                                    <div class="dmRespColsWrapper">
                                                        <div class="large-12 dmRespCol">
                                                            <div id="innerBar" class="innerBar lineInnerBar dmDisplay_None">
                                                                <div class="titleLine display_None">
                                                                    <hr>
                                                                </div>
                                                                <!-- Page title is hidden in css for new responsive sites. It is left here only so we don't break old sites. Don't copy it to new layouts -->
                                                                <div id="pageTitleText"></div>
                                                                <div class="titleLine display_None">
                                                                    <hr>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div dmwrapped="true" id="dmTempContainer" class="dmBody u_dmStyle_template_home dm-home-page" themewaschanged="true" style="transition: transform 0.4s cubic-bezier(0.1, 0.1, 0.25, 0.9) 0s, opacity 0.4s cubic-bezier(0.1, 0.1, 0.25, 0.9) 0s; transform: none; width: 1583px; height: 795px; position: absolute; top: 0px; display: none;"></div>
                                                <div dmwrapped="true" id="dmFirstContainer" class="dmBody u_dmStyle_template_home dm-home-page" themewaschanged="true" style="transition: transform 0.4s cubic-bezier(0.1, 0.1, 0.25, 0.9) 0s, opacity 0.4s cubic-bezier(0.1, 0.1, 0.25, 0.9) 0s; transform: none;">
                                                    <div id="allWrapper" class="allWrapper">
                                                        <!-- navigation placeholders -->
                                                        <div id="dm_content" class="dmContent">
                                                            <div dm:templateorder="170" class="dmHomeRespTmpl mainBorder dmRespRowsWrapper dmFullRowRespTmpl dmRespRowsWrapperSize1" id="1716942098" style="min-height: 207px;">
                                                                <div class="u_1634323953 dmRespRow fullBleedChanged fullBleedMode" style="text-align: center;" id="1634323953">
                                                                    <div class="dmRespColsWrapper" id="1955865946">
                                                                        <div class="u_1521084018 dmRespCol small-12 medium-12 large-12" id="1521084018">
                                                                            <h2 class="u_1315689810 dmNewParagraph" id="1315689810" data-uialign="left" data-element-type="paragraph" data-styletopreserve="{" background-image="" :="">
                                                                            <div style="text-align: center;">
                                                                                <span style="color: rgb(255, 255, 255); font-family: Raleway; font-size: 16px;">&nbsp;</span><span style="font-family: Raleway; text-decoration-line: underline;" class="font-size-26 lh-1"><font style="color: rgb(0, 255, 0);">Welcome To Electronic Waves Radio.&nbsp;</font></span>
                                                                            </div><font style=""></font><span style="font-weight: 600; font-family: Raleway;"><font style="color: rgb(255, 255, 255);">
                                                                                    <div style="text-align: center;">
                                                                                        <font style="">
                                                                                            <br>
                                                                                        </font>
                                                                                    </div>
                                                                                    <div style="text-align: center;">
                                                                                        <font style="">Dedicated to broadcasting the finest Dance Music across the globe.</font>
                                                                                    </div>
                                                                                    <div style="text-align: center;">
                                                                                        <font style="">Whether your into, House, Tech,Progressive,Drum and Bass,Trance,Techno,Funk,Disco,Hardcore, Electronica and Old School Classics you will find them all on E.W.R&nbsp;</font>
                                                                                    </div>
                                                                                    <div style="text-align: center;">
                                                                                        <font style="">With 24/7 playlists and Live D.J sets being regularly added this station is guaranteed to get a foot tapping and any party moving !<span class="font-size-20 lh-1" style="font-weight: inherit;">&nbsp;</span></font>
                                                                                    </div></font></span>
                                                                            <div>
                                                                                <font style="color: rgb(6, 195, 248);"><span class="font-size-20 lh-1" style=""></span></font>
                                                                            </div></h2>
                                                                            <div class="dmDividerWrapper clearfix hasFullWidth u_1421492621" data-element-type="dDividerId" data-layout="divider-style-1" data-widget-version="2" id="1421492621">
                                                                                <hr class="dmDivider" style="border-width:2px; border-top-style:solid; color:grey;" id="1123400645">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="u_1583792189 dmRespRow fullBleedChanged fullBleedMode" style="text-align: center;" id="1583792189">
                                                                    <div class="dmRespColsWrapper" id="1409617896">
                                                                        <div class="u_1390352536 dmRespCol small-12 large-4 medium-4" id="1390352536">
                                                                            <a data-display-type="block" class="u_1347635963 align-center dmButtonLink dmWidget dmWwr default dmOnlyButton dmDefaultGradient" file="false" href="https://www.electronicwavesradio.com/listen-live" id="1347635963" data-element-type="dButtonLinkId" dm_dont_rewrite_url="false" data-buttonstyle="SQUISHY" target="_blank"> <span class="iconBg" id="1354680145"> <span class="icon hasFontIcon icon-star" id="1556498903"></span> </span> <span class="text" id="1364826078">Listen Here</span> </a>
                                                                            <div data-element-type="html" class="dmCustomHtml u_1224569462" id="1224569462">
                                                                                <div id="rk_widget_currenttrack_199069" class="rk_widget_currenttrack">
                                                                                    <table class="rk_widget_currenttrack_table">
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td><img width="40" height="40" src="./Electronic Waves Home_files/b02e01b7-406f-4fa1-bf54-fab73a74819d" alt=""></td><td class="rk_widget_recenttracks_title">Live DJ Set</td><td>See Schedule</td>
                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                </div>
                                                                                <script type="text/javascript" src="./Electronic Waves Home_files/currenttrack.js.download"></script>
                                                                            </div>
                                                                        </div>
                                                                        <div class="u_1461072190 dmRespCol small-12 large-8 medium-8 emptyColumn" id="1461072190">
                                                                            <div class="u_1075985253 dmTwitterFeedWrapper wow fadeInRight animated" data-element-type="dTwitterId" id="1075985253" data-anim-desktop="fadeInRight" style="visibility: visible; animation-name: fadeInRight;">
                                                                                <div class="dmTwitterFeed dmWwr dmTwitterNoScroll" twitterusername="ElectronicWave5" numberoftweets="2" twittertype="Profile" hideheaderfooter="true" lang="en-gb" id="1423551427">
                                                                                    <iframe id="twitter-widget-0" scrolling="no" frameborder="0" allowtransparency="true" allowfullscreen="true" class="twitter-timeline twitter-timeline-rendered" style="position: static; visibility: visible; display: inline-block; width: 520px; padding: 0px; border: none; max-width: 100%; min-width: 180px; margin-top: 0px; margin-bottom: 0px; height: 625.984px;" data-widget-id="profile:ElectronicWave5" title="Twitter Timeline" src="./Electronic Waves Home_files/saved_resource.html"></iframe><div class="dmTwitterRuntimeWrapper"></div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="u_1584503777 dmRespRow fullBleedChanged fullBleedMode" style="text-align: center;" id="1584503777">
                                                                    <div class="dmRespColsWrapper" id="1649402586">
                                                                        <div class="dmRespCol small-12 u_1490733586 medium-12 large-12" id="1490733586">
                                                                            <div class="dmNewParagraph" data-dmtmpl="true" data-element-type="paragraph" id="1167637661" style="transition: opacity 1s ease-in-out 0s;">
                                                                                <span class="font-size-26 lh-1">&nbsp;</span>
                                                                                <div>
                                                                                    <span style="" class="font-size-28 lh-1"><font style="color: rgb(6, 195, 248);">What's On......</font></span>
                                                                                </div>
                                                                            </div>
                                                                            <div class="u_1473184987 widget-1b7098 dmCustomWidget wow fadeInLeft animated" id="1473184987" dmle_extension="custom_extension" data-element-type="custom_extension" wr="false" data-anim-desktop="fadeInLeft" icon="false" surround="false" data-widget-id="1b70982e7b474a1dbfcdcb76432af84d" data-widget-version="4" data-widget-config="eyJnY2FsZW5kYXJfZGlzcGxheV9tb2RlIjoiaW50ZWdyYXRlZCIsImdjYWxlbmRhcl9kaXNwbGF5X2xpbmsiOiJTaG93IGNhbGVuZGFyIiwiZ2NhbGVuZGFyX2VtYWlsIjoiZWxlY3Ryb25pY3dhdmVzcmFkaW9AZ21haWwuY29tIn0=" style="visibility: visible; animation-name: fadeInLeft;">
                                                                                <iframe class="widget-google-calendar-1and1" name="widget-google-calendar-1and1" src="./Electronic Waves Home_files/embed.html" style="border: 0" width="100%" height="600" frameborder="0" scrolling="no"></iframe>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="u_1657596502 dmRespRow" style="text-align: center;" id="1657596502">
                                                                    <div class="dmRespColsWrapper" id="1208089163">
                                                                        <div class="u_1913949870 dmRespCol small-12 medium-6 large-6 wow fadeInLeft" id="1913949870" data-anim-desktop="fadeInLeft" style="visibility: hidden; animation-name: none;">
                                                                            <h3 class="u_1312263663 dmNewParagraph" data-element-type="paragraph" id="1312263663" data-uialign="left" style="text-align: center; transition: opacity 1s ease-in-out 0s;"><span style="font-weight: 100;"><span style="" class="font-size-30 lh-1"><span style="font-family: Raleway; font-weight: 400;"><font style="color: rgb(0, 255, 0);">&nbsp; &nbsp;The Power Of <span style="" class="lh-1">The</span> Internet</font></span><span style="color: rgb(49, 49, 49); font-weight: 100; font-family: Raleway;">&nbsp;</span></span></span></h3>
                                                                            <div class="u_1722495965 dmNewParagraph" data-dmtmpl="true" id="1722495965" data-uialign="left" style="transition: none; display: block;">
                                                                                <div>
                                                                                    <font style="color: rgb(49, 49, 49);" class="font-size-16 lh-1 m-specific m-font-size-14"><b></b></font>
                                                                                </div>
                                                                                <div style="">
                                                                                    <font style="color: rgb(49, 49, 49);" class="font-size-16 lh-1 m-specific m-font-size-14"></font>
                                                                                </div><span style="font-weight: 400;">
                                                                                    <div style="">
                                                                                        <font style=""><span style="font-weight: 400;"><font style="color: rgb(6, 195, 248);" class="lh-1 font-size-28"><span class="font-size-26 lh-1">&nbsp;</span>Our humble station is broadcast from Leeds, U.K to the rest of the world. Reaching 98 Countries worldwide in only the 1st month of being "On Air" . Talented D.J's are hosting their own Live shows and showcasing their talents via the internet from where ever they are located in the world.</font><font style="font-size: 16px; color: rgb(49, 49, 49);">&nbsp;</font></span></font>
                                                                                    </div></span>
                                                                                <div style="">
                                                                                    <font style="color: rgb(49, 49, 49);" class="font-size-16 lh-1 m-specific m-font-size-14"></font>
                                                                                </div>
                                                                                <div>
                                                                                    <font style="color: rgb(49, 49, 49);" class="font-size-16 lh-1 m-specific m-font-size-14"><b></b></font>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="dmRespCol small-12 medium-6 large-6 u_1614526724" id="1614526724">
                                                                            <div class="u_1261753765 imageWidget align-center wow fadeInRight" editablewidget="true" data-element-type="image" data-widget-type="image" id="1261753765" data-anim-desktop="fadeInRight" style="visibility: hidden; animation-name: none;"><img src="./Electronic Waves Home_files/124254.jpeg" id="1168007288" class="" data-dm-image-path="https://cdn.website-editor.net/md/and1/dms3rep/multi/124254.jpeg" onerror="handleImageLoadError(this)">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="u_1777656344 dmRespRow fullBleedChanged fullBleedMode" style="text-align: center;" id="1777656344">
                                                                    <div class="dmRespColsWrapper" id="1763420047">
                                                                        <div class="dmRespCol small-12 medium-6 large-6 u_1585363487" id="1585363487">
                                                                            <h3 class="u_1181287235 dmNewParagraph" id="1181287235" style="transition-duration: 1s; transition-timing-function: ease-in-out; transition-delay: initial; transition-property: opacity; display: block;" data-uialign="left" data-editor-state="closed" data-element-type="paragraph">
                                                                            <div style="">
                                                                                <span style="font-size: 35px;"><b><span style="font-weight: 400;"><font style="color: rgb(0, 255, 0);"><span style="font-weight: 400; font-family: Raleway;">Send us a message</span></font></span></b></span>
                                                                            </div></h3>
                                                                            <div class="u_1569787165 dmNewParagraph" data-dmtmpl="true" id="1569787165" data-uialign="left" style="transition: none;">
                                                                                <div style="text-align: center;">
                                                                                    <div style="text-align: left;">
                                                                                        <font style="color: rgb(6, 195, 248);"><font><span style="font-size: 18px;">Have a question? We’re here to help.&nbsp;</span></font><span style="font-size: 18px;">Send us a message and we’ll be in touch.&nbsp;</span></font>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="u_1451643793 dmform default" preserve_css="true" id="1451643793" data-element-type="dContactUsRespId" data-layout="layout-2">
                                                                                <h3 class="dmform-title dmwidget-title" id="1049216074" hide="true"></h3>
                                                                                <div class="dmform-wrapper" preserve_css="true" id="1456768816" captcha-lang="en">
                                                                                    <form method="post" class="dmRespDesignRow" locale="ENGLISH" id="1545455437">
                                                                                        <div class="dmforminput required  small-12 dmRespDesignCol medium-12 large-12" id="1314576073">
                                                                                            <label for="dmform-0" id="1473830478" class="" style="width: 78px;">First name</label>
                                                                                            <input type="text" class="" name="dmform-0" id="1988532551" style="width: 589px;">
                                                                                            <input type="hidden" name="label-dmform-0" id="1593527262" class="" value="First name">
                                                                                        </div>
                                                                                        <div class="dmforminput small-12 dmRespDesignCol medium-12 large-12" id="1488496509">
                                                                                            <label for="dmform-5" id="1055861907" style="width: 78px;">Last name</label>
                                                                                            <input type="text" name="dmform-5" id="1510707362" style="width: 589px;">
                                                                                            <input type="hidden" name="label-dmform-5" value="Last name" id="1624513249" class="">
                                                                                        </div>
                                                                                        <div class="dmforminput required  small-12 dmRespDesignCol medium-12 large-12" id="1267592498">
                                                                                            <label for="dmform-1" id="1393514649" class="" style="width: 78px;">Email</label>
                                                                                            <input type="email" class="" name="dmform-1" id="1831431370" style="width: 589px;">
                                                                                            <input type="hidden" name="label-dmform-1" id="1901399423" class="" value="Email">
                                                                                        </div>
                                                                                        <div class="dmforminput large-12 medium-12 dmRespDesignCol small-12" id="1897181740">
                                                                                            <label for="dmform-3" id="1284996576" class="" style="width: 78px;">Message</label>
                                                                                            <textarea name="dmform-3" id="1010394991" class="" style="width: 589px;"></textarea>
                                                                                            <input type="hidden" name="label-dmform-3" id="1929021210" class="" value="Message">
                                                                                        </div>
                                                                                        <span id="1842194549" class="dmWidgetClear"></span>
                                                                                        <span id="1038958716" class="dmWidgetClear"></span>
                                                                                        <div class="dmformsubmit dmWidget R" preserve_css="true" id="1786557055">
                                                                                            <input class="" name="submit" type="submit" value="Submit" id="1402764805">
                                                                                        </div>
                                                                                        <input name="dmformsendto" type="hidden" value="O0wrseIfFLvunlQVM0XpJrbfgvfuMJkAd3dGxWxo1b+fTGr4RMk30iUSgOcssFgcYG6BrFTNcwJvsjMBZ8odQQ==" preserve_css="true" id="1539082220" class="" data-dec="true">
                                                                                        <input class="dmActionInput" type="hidden" name="action" value="/_dm/s/rt/widgets/dmform.submit.jsp" id="1499987121">
                                                                                        <input name="dmformsubject" type="hidden" value="Form message" preserve_css="true" id="1788062498">
                                                                                    </form>
                                                                                </div>
                                                                                <div class="dmform-success" style="display:none" preserve_css="true" id="1145470036">
                                                                                    Thank you for contacting us.
                                                                                    <br id="1240833361">
                                                                                    We will get back to you as soon as possible
                                                                                </div>
                                                                                <div class="dmform-error" style="display:none" preserve_css="true" id="1287838703">
                                                                                    Uh oh, there was an error sending your message.
                                                                                    <br id="1579317790">
                                                                                    Please try again later
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="dmRespCol small-12 medium-6 large-6 u_1130094537" id="1130094537">
                                                                            <div class="u_1729580699 default dmDefaultGradient align-center inlineMap" data-type="inlineMap" data-lat="53.7948" data-lng="-1.54653" data-address="Leeds, England, United Kingdom" data-height="" data-msid="" data-mapurl="" data-lang="en" data-color-scheme="" data-zoom="" data-layout="layout1" data-popup-display="" data-popup-show="false" data-popup-title="" data-popup-title-visible="false" data-popup-description="" data-popup-description-visible="false" id="1729580699" dmle_extension="mapextension" data-element-type="mapextension" wr="true" modedesktop="map" modemobile="map" addresstodisplay="Leeds, England, United Kingdom" geocompleteaddress="Leeds, England, United Kingdom" data-popup-display-desktop="" zoom="" data-popup-display-mobile="" data-display-type="block" layout="layout1" modetablet="map" icon="true" surround="true" description="Find us" adwords="" icon-name="icon-map-marker" street="" city="" country="US" country_full="United States" state="" zip="" provider="mapbox" lon="-1.54653" lat="53.7948">
                                                                                <div class="mapContainer mapboxgl-map" style="height: 100%; width: 100%; overflow: hidden; z-index: 0;">
                                                                                    <div class="mapboxgl-canary" style="visibility: hidden;"></div>
                                                                                    <div class="mapboxgl-canvas-container mapboxgl-interactive mapboxgl-touch-drag-pan mapboxgl-touch-zoom-rotate">
                                                                                        <canvas class="mapboxgl-canvas" tabindex="0" aria-label="Map" width="702" height="493" style="position: absolute; width: 702px; height: 493px;"></canvas><div class="marker map-marker mapboxgl-marker mapboxgl-marker-anchor-center" style="transform: translate(-50%, -50%) translate(351px, 247px);"></div>
                                                                                    </div>
                                                                                    <div class="mapboxgl-control-container">
                                                                                        <div class="mapboxgl-ctrl-top-left">
                                                                                            <div class="mapboxgl-ctrl mapboxgl-ctrl-group">
                                                                                                <button class="mapboxgl-ctrl-icon mapboxgl-ctrl-zoom-in" type="button" title="Zoom in" aria-label="Zoom in"></button><button class="mapboxgl-ctrl-icon mapboxgl-ctrl-zoom-out" type="button" title="Zoom out" aria-label="Zoom out"></button>
                                                                                                <button class="mapboxgl-ctrl-icon mapboxgl-ctrl-compass" type="button" title="Reset bearing to north" aria-label="Reset bearing to north">
                                                                                                    <span class="mapboxgl-ctrl-compass-arrow" style="transform: rotate(0deg);"></span>
                                                                                                </button>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="mapboxgl-ctrl-top-right">
                                                                                            <div class="mapboxgl-ctrl mapboxgl-ctrl-group">
                                                                                                <button class="mapboxgl-ctrl-icon mapboxgl-ctrl-fullscreen" aria-label="Toggle fullscreen" type="button"></button>
                                                                                            </div>
                                                                                            <div class="mapboxgl-ctrl mapboxgl-ctrl-group">
                                                                                                <button class="switcher map-switcher"></button>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="mapboxgl-ctrl-bottom-left">
                                                                                            <div class="mapboxgl-ctrl" style="display: block;">
                                                                                                <a class="mapboxgl-ctrl-logo" target="_blank" href="https://www.mapbox.com/" aria-label="Mapbox logo" rel="noopener"></a>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="mapboxgl-ctrl-bottom-right">
                                                                                            <div class="mapboxgl-ctrl mapboxgl-ctrl-attrib">
                                                                                                <div class="mapboxgl-ctrl-attrib-inner">
                                                                                                    <a href="https://www.mapbox.com/about/maps/" target="_blank">© Mapbox</a><a href="http://www.openstreetmap.org/about/" target="_blank">© OpenStreetMap</a><a class="mapbox-improve-map" href="https://www.mapbox.com/feedback/?owner=dannyb123&amp;id=cj1nokhth002h2ro98mhwrfje&amp;access_token=pk.eyJ1IjoiZGFubnliMTIzIiwiYSI6ImNqMGljZ256dzAwMDAycXBkdWxwbDgzeXYifQ.Ck5P-0NKPVKAZ6SH98gxxw" target="_blank">Improve this map</a>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="u_1264855164 dmRespRow hasBackgroundOverlay dmSectionNoParallax fullBleedChanged fullBleedMode" style="text-align: center;" id="1264855164">
                                                                    <div class="dmRespColsWrapper" id="1758792769">
                                                                        <div class="dmRespCol small-12 medium-12 large-12" id="1089951984"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="dmFooterContainer">
                                                    <div id="fcontainer" class="f_hcontainer dmFooter p_hfcontainer">
                                                        <div dm:templateorder="250" class="dmFooterResp generalFooter" id="1943048428">
                                                            <div class="u_1324271865 dmRespRow fullBleedChanged fullBleedMode" style="text-align: center;" id="1324271865">
                                                                <div class="dmRespColsWrapper" id="1195730571">
                                                                    <div class="dmRespCol small-12 u_1306052360 medium-4 large-4" id="1306052360">
                                                                        <div class="u_1786585439 imageWidget align-center" editablewidget="true" data-element-type="image" data-widget-type="image" id="1786585439"><img src="./Electronic Waves Home_files/IMG_0096(1).PNG" id="1382114039" class="" data-dm-image-path="https://cdn.website-editor.net/661b5333962b49ba8fdfe2ded2230e5e/dms3rep/multi/IMG_0096.PNG" onerror="handleImageLoadError(this)">
                                                                        </div>
                                                                    </div>
                                                                    <div class="u_1493562304 dmRespCol small-12 medium-4 large-4" id="1493562304">
                                                                        <div class="u_1859940122 widget-85b0db dmCustomWidget" id="1859940122" dmle_extension="custom_extension" data-element-type="custom_extension" wr="false" icon="false" surround="false" data-widget-id="85b0db3860664a28b3031e6cd70abf8c" data-widget-version="34" data-widget-config="eyJkaXJlY3Rpb24iOiJyaWdodCIsImltYWdlIjoiaHR0cHM6Ly9jZG4ud2Vic2l0ZS1lZGl0b3IubmV0LzY2MWI1MzMzOTYyYjQ5YmE4ZmRmZTJkZWQyMjMwZTVlL2RtczNyZXAvbXVsdGkvUmFkaW9LaW5nX2xvZ28rY2FycmUucG5nIiwidGV4dCI6IjxwIGNsYXNzPVwicnRlQmxvY2tcIj48c3Ryb25nPjxzcGFuIHN0eWxlPVwiY29sb3I6cmdiYSg2LCAxOTUsIDI0OCwgMSlcIj5Qb3dlcmVkIEJ5wqA8L3NwYW4+PC9zdHJvbmc+PC9wPiJ9">
                                                                            <div class="wrapper">
                                                                                <div class="spacer spacer-right"></div>
                                                                                <img alt="" class="image right" src="./Electronic Waves Home_files/RadioKing_logo+carre.png" onerror="handleImageLoadError(this)">
                                                                                <div class="text">
                                                                                    <span class="text-inner"> <p></p>
                                                                                        <p class="rteBlock">
                                                                                            <strong> <span style="color:rgba(6, 195, 248, 1)">Powered By&nbsp;</span> </strong>
                                                                                        </p> <p></p> </span>
                                                                                </div>
                                                                                <div style="clear:both"></div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="dmRespCol small-12 u_1123290715 medium-4 large-4" id="1123290715">
                                                                        <div class="u_1324884313 widget-1f5975 dmCustomWidget" id="1324884313" dmle_extension="custom_extension" data-element-type="custom_extension" wr="false" icon="false" surround="false" data-widget-id="1f5975986930429f819d4cd2154b5c4a" data-widget-version="22" data-widget-config="eyJjb3B5cmlnaHRUZXh0IjoiPHAgY2xhc3M9XCJydGVCbG9ja1wiPkFsbCBSaWdodHMgUmVzZXJ2ZWQgfCBFbGVjdHJvbmljIFdhdmVzIFJhZGlvPC9wPiIsInJldmVyc2VGbGFnIjp0cnVlfQ==">
                                                                            <div class="copyright">
                                                                                <div>
                                                                                    <p class="rteBlock">
                                                                                        All Rights Reserved | Electronic Waves Radio
                                                                                    </p>
                                                                                </div>
                                                                                <div>
                                                                                    &nbsp;© 2019
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div id="1236746004" dmle_extension="powered_by" data-element-type="powered_by" wr="false" icon="true" surround="false" data-dmtmpl="true"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!--  Add full CSS and Javascript before the close tag of the body if needed -->
        <script type="text/javascript">
            ( function() {
                    var campaign = (/utm_campaign=([^&]*)/).exec(window.location.search);

                    if (campaign && campaign != null && campaign.length > 1) {
                        campaign = campaign[1];
                        document.cookie = "_dm_rt_campaign=" + campaign + ";expires=" + new Date().getTime() + 24 * 60 * 60 * 1000 + ";domain=" + window.location.hostname + ";path=/";
                    }
                }());
        </script>
        <script type="text/javascript">
            var _dm_gaq = {};
            var _gaq = _gaq || [];
            var _dm_insite = [];

            ;( function(p, l, o, w, i, n, g) {
                    if (!p[i]) {
                        p.GlobalSnowplowNamespace = p.GlobalSnowplowNamespace || [];
                        p.GlobalSnowplowNamespace.push(i);
                        p[i] = function() {
                            (p[i].q = p[i].q || []).push(arguments)
                        };
                        p[i].q = p[i].q || [];
                        n = l.createElement(o);
                        g = l.getElementsByTagName(o)[0];
                        n.async = 1;
                        n.src = w;
                        g.parentNode.insertBefore(n, g)
                    }
                }(window, document, "script", "//d1dxoqu0t5mb7j.cloudfront.net/sp-2.0.0-dm-0.1.min.js", "snowplow"));
            window.dmsnowplow = window.snowplow;

            dmsnowplow('newTracker', 'cf', 'd1dxoqu0t5mb7j.cloudfront.net', {// Initialise a tracker
                appId : '661b5333962b49ba8fdfe2ded2230e5e'
            });

            dmsnowplow('trackPageView')
            $.each(_dm_insite, function(idx, rule) {
                //('trackStructEvent', 'category','action','label','property','value');
                // Specifically in popup only the client knows if it is shown or not so we don't always want to track its impression here
                // the tracking is in popup.js
                if (rule.actionName !== "popup") {
                    dmsnowplow('trackStructEvent', 'insite', 'impression', rule.ruleType, rule.ruleId);
                }
                $(document).ready(function() {
                    $.DM.events.trigger('event-ruleTriggered', {
                        value : rule
                    })
                });
            });
        </script>

        <div style="display:none;" id="P6iryBW0Wu"></div>

        <!-- photoswipe markup -->

        <!-- Root element of PhotoSwipe. Must have class pswp. -->
        <div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">

            <!-- Background of PhotoSwipe.
            It's a separate element as animating opacity is faster than rgba(). -->
            <div class="pswp__bg"></div>

            <!-- Slides wrapper with overflow:hidden. -->
            <div class="pswp__scroll-wrap">

                <!-- Container that holds slides.
                PhotoSwipe keeps only 3 of them in the DOM to save memory.
                Don't modify these 3 pswp__item elements, data is added later on. -->
                <div class="pswp__container">
                    <div class="pswp__item"></div>
                    <div class="pswp__item"></div>
                    <div class="pswp__item"></div>
                </div>

                <!-- Default (PhotoSwipeUI_Default) interface on top of sliding area. Can be changed. -->
                <div class="pswp__ui pswp__ui--hidden">

                    <div class="pswp__top-bar">

                        <!--  Controls are self-explanatory. Order can be changed. -->

                        <div class="pswp__counter"></div>

                        <button class="pswp__button pswp__button--close" title="Close (Esc)"></button>

                        <button class="pswp__button pswp__button--share" title="Share"></button>

                        <button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button>

                        <button class="pswp__button pswp__button--zoom" title="Zoom in/out"></button>

                        <!-- Preloader demo http://codepen.io/dimsemenov/pen/yyBWoR -->
                        <!-- element will get class pswp__preloader--active when preloader is running -->
                        <div class="pswp__preloader">
                            <div class="pswp__preloader__icn">
                                <div class="pswp__preloader__cut">
                                    <div class="pswp__preloader__donut"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
                        <div class="pswp__share-tooltip"></div>
                    </div>

                    <button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)"></button>

                    <button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)"></button>

                    <div class="pswp__caption">
                        <div class="pswp__caption__center"></div>
                    </div>

                </div>

            </div>

        </div>
        <!-- note these also must be called after ajax -->
        <script>
            var dmForceShare = false;
            if (dmForceShare || $("#shareSection").length > 0 || $(".dmShare").length > 0) {
                dmLoadShare();
            }

            function dmLoadShare() {
                /* google plus shares */
                $.ajax({
                    url : "https://apis.google.com/js/plusone.js",
                    dataType : "script",
                    success : function() {
                    }
                });
                /* linked in shares */
                $.ajax({
                    url : "https://platform.linkedin.com/in.js",
                    dataType : "script",
                    success : function() {
                    }
                });
                /* Twitter Shares */
                $.ajax({
                    url : "https://platform.twitter.com/widgets.js",
                    dataType : "script",
                    success : function() {
                    }
                });
            }
        </script>
        <div id="fb-root" data-locale="en_GB"></div>

        <!-- Alias: 661b5333962b49ba8fdfe2ded2230e5e -->
        <div class="dmPopupMask" id="dmPopupMask"></div>
        <div id="dmPopup" class="dmPopup">
            <div class="dmPopupCloseWrapper">
                <div class="dmPopupClose dm-icon-x_close_popup oneIcon" onclick="dmHidePopup(event);"></div>
            </div>
            <div class="dmPopupTitle">
                <span></span> Share by:
            </div>
            <div class="data"></div>
        </div>
        <script>
            // Collects client data and updates cookies used by smart sites
            var expireDays = 365,
                visitLength = 30 * 60000;
            $.setCookie("dm_timezone_offset", (new Date()).getTimezoneOffset(), expireDays);
            function setSmartSiteCookies() {
                setSmartSiteCookiesInternal("dm_this_page_view", "dm_last_page_view", "dm_total_visits", "dm_last_visit");
            }


            $.DM.events.on("afterAjax", setSmartSiteCookies);
            setSmartSiteCookies();
        </script>
        <script type="text/javascript">
            $.extend(Parameters, {
                AjaxContainer : "div.dmBody",
                WrappingContainer : "div.dmOuter",
                HomeUrl : "https://www.electronicwavesradio.com/",
                AccountUUID : "ec67f6f7a96244188e27982dd3aee63d",
                SiteAlias : "661b5333962b49ba8fdfe2ded2230e5e",
                SiteId : "226564",
                SiteType : eval(Base64.decode("J0RVREFPTkUn")),
                ExternalUid : '7fd00126-2bbb-47d2-81a2-e16756ed50c1',
                IsSEOFriendlyLinks : true,
                IsSiteMultilingual : false,
                InitialPostAlias : '',
                InitialPageAlias : "home",
                InitialEncodedPageAlias : "aG9tZQ==",
                IsFromScratch : "false",
                CurrentPageUrl : "",
                IsCurrentHomePage : true,
                classicLink : "",
                AllowAjax : true,
                AfterAjaxCommand : null,
                HomeLinkText : "Back To Home",
                UseGalleryModule : false,
                CurrentThemeName : "Layout Theme",
                ThemeVersion : "745",
                DefaultPageAlias : "",
                RemoveDID : true,
                LayoutVariationID : {
                    desktop : 5
                },
                LayoutID : {
                    desktop : 6
                },
                WidgetStyleID : null,
                IsHeaderFixed : false,
                IsHeaderSkinny : false,
                IsBfs : true,
                LayoutParams : {
                    _manifestId : 10600,
                    _device : "desktop"
                },
                StorePageAlias : "null",
                StorePath : "",
                StoreId : "null",
                StoreVersion : 0,
                StoreBaseUrl : "",
                StoreCleanUrl : true,
                StoreDisableScrolling : true,
                NotificationSubDomain : "electronicwavesradio",
                HasCustomDomain : true,
                showCookieNotification : true,
                cookiesNotificationMarkup : ' <div>In order to provide you with the best online experience this website uses cookies. By using our website, you agree to our use of cookies. <a href=\"\/privacy\" target=\"_blank\">More Info<\/a>.<\/div> \n',
                translatedPageUrl : '',
                isFastMigrationSite : false,
                sidebarPosition : 'LEFT',
                currentLanguage : "en",
                NavItems : "W3sidGl0bGUiOiJXZWxjb21lIFRvIEVsZWN0cm9uaWMgV2F2ZXMgUmFkaW8iLCJhbGlhcyI6ImhvbWUiLCJwYXRoIjoiLyIsImluTmF2aWdhdGlvbiI6dHJ1ZSwic3ViTmF2IjpbXX0seyJ0aXRsZSI6Ikxpc3RlbiBMaXZlIiwiYWxpYXMiOiJsaXN0ZW4tbGl2ZSIsInBhdGgiOiIvbGlzdGVuLWxpdmUiLCJpbk5hdmlnYXRpb24iOnRydWUsInN1Yk5hdiI6W119LHsidGl0bGUiOiJFbGVjdHJvbmljIFdhdmVzIERpc2MgSm9ja2V5cyIsImFsaWFzIjoiREpzIiwicGF0aCI6Ii9ESnMiLCJpbk5hdmlnYXRpb24iOnRydWUsInN1Yk5hdiI6W119LHsidGl0bGUiOiJEaXJlY3RvcmllcyBBbmQgUHJvdmlkZXJzIiwiYWxpYXMiOiJkaXJlY3Rvcmllcy1hbmQtcHJvdmlkZXJzIiwicGF0aCI6Ii9kaXJlY3Rvcmllcy1hbmQtcHJvdmlkZXJzIiwiaW5OYXZpZ2F0aW9uIjp0cnVlLCJzdWJOYXYiOltdfV0=",
                errors : {
                    general : 'There was an error connecting to the page.<br/> Make sure you are not offline.',
                    password : 'Incorrect name/password combination',
                    tryAgain : 'Try again'
                }
            });
            $.extend(Parameters.NavigationAreaParams, {
                ShowBackToHomeOnInnerPages : true,
                NavbarSize : 4,
                NavbarLiveHomePage : "https://www.electronicwavesradio.com/",
                BlockContainerSelector : ".dmBody",
                NavbarSelector : "#dmNav:has(a)",
                SubNavbarSelector : "#subnav_main"
            });
            $.extend(Parameters.LayoutParams, {
                _navigationAnimationStyle : 'slide'
            });

            Parameters.NavigationAreaParams.MoreButtonText = '......';

            Parameters.NavigationAreaParams.LessButtonText = '......';
            Parameters.HomeLinkText = 'Home';
        </script>

        <script>
            jQuery(window).load(function() {
                try {
                    jQuery.DM.updateIOSHeight();
                } catch(e) {
                };
            });
        </script>
        <script>
            dmAPI.loadScript('https://cdn.jsdelivr.net/npm/lozad/dist/lozad.min.js', function() {
                dmAPI.runOnReady('lozadInit', function() {
                    window.document.querySelectorAll('img.lazy').forEach(function(img) {
                        img.addEventListener('load', function(event) {
                            var img = event.target;
                            img.style.filter = 'blur(0)';
                            setTimeout(function() {
                                $(img).closest('.imageWidget').addClass('lazyLoaded');
                            }, 250)
                        });
                    });
                    lozad('.lazy', {
                        threshold : 0.1,
                        loaded : function(element) {
                            if (element.getAttribute('data-background-image')) {
                                element.style.setProperty('background-image', "url('" + element.getAttribute('data-background-image') + "')", "important");
                            }
                        }
                    }).observe();
                });
            });
        </script>
        <!--  End Script tags -->

        <!--  Site Wide Html Markup -->
        <!--  Site Wide Html Markup -->

        <!--  Begin Product Custom HTML Markup -->
        <script>
            function call1and1Tracking() {
                var externalId = dmAPI.getSiteExternalId();
                var siteName = dmAPI.getSiteName();
                var src = 'https://integration.mywebsite-editor.com/dakota-snippet-service/snippet/integration/snippet.js?sitename=' + siteName + '&external_uid=' + externalId + '&mode=visit'
                var tracking = document.createElement('script');
                tracking.setAttribute('src', src);
                document.head.appendChild(tracking);
            }

            call1and1Tracking();
        </script>

        <!--  End Product Custom HTML Markup -->

        <!--[oneand-run-as-0af2f0a4934952859, 2019-04-10 22:13:20]--><span id="buffer-extension-hover-button" style="display: none; position: absolute; z-index: 8675309; width: 100px; height: 25px; background-image: url(&quot;chrome-extension://noojglkidnpfjbincgijbaiedldjfbhh/data/shared/img/buffer-hover-icon@1x.png&quot;); background-size: 100px 25px; opacity: 0.9; cursor: pointer;"></span><iframe scrolling="no" frameborder="0" allowtransparency="true" src="./Electronic Waves Home_files/widget_iframe.2e9f365dae390394eb8d923cba8c5b11.html" title="Twitter settings iframe" style="display: none;"></iframe><iframe id="rufous-sandbox" scrolling="no" frameborder="0" allowtransparency="true" allowfullscreen="true" style="position: absolute; visibility: hidden; display: none; width: 0px; height: 0px; padding: 0px; border: none;" title="Twitter analytics iframe" src="./Electronic Waves Home_files/saved_resource(1).html"></iframe>
    </body>
</html>